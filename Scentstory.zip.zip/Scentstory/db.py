import pymysql
import pymysql.cursors
import sqlite3
import os
from config import Config

_USE_SQLITE = False

def get_db_connection():
    global _USE_SQLITE
    if not _USE_SQLITE:
        try:
            conn = pymysql.connect(
                host=Config.DB_HOST,
                port=Config.DB_PORT,
                user=Config.DB_USER,
                password=Config.DB_PASSWORD,
                database=Config.DB_NAME,
                charset='utf8mb4',
                cursorclass=pymysql.cursors.DictCursor,
                autocommit=True
            )
            return conn, False
        except Exception as e:
            print(f"[DB Warning] MySQL connection failed ({e}). Falling back to SQLite.")
            _USE_SQLITE = True

    # Fallback SQLite connection
    conn = sqlite3.connect(Config.SQLITE_PATH)
    conn.row_factory = sqlite3.Row
    return conn, True

def query_db(query, args=(), one=False):
    conn, is_sqlite = get_db_connection()
    try:
        if is_sqlite:
            # Replace %s with ? for SQLite compatibility
            sqlite_query = query.replace('%s', '?')
            cur = conn.cursor()
            cur.execute(sqlite_query, args)
            rv = cur.fetchall()
            cur.close()
            # Convert sqlite3.Row to dict
            result = [dict(row) for row in rv]
            return (result[0] if result else None) if one else result
        else:
            with conn.cursor() as cur:
                cur.execute(query, args)
                rv = cur.fetchall()
                return (rv[0] if rv else None) if one else rv
    finally:
        conn.close()

def execute_db(query, args=(), return_id=False):
    conn, is_sqlite = get_db_connection()
    try:
        if is_sqlite:
            sqlite_query = query.replace('%s', '?')
            cur = conn.cursor()
            cur.execute(sqlite_query, args)
            conn.commit()
            last_id = cur.lastrowid
            cur.close()
            return last_id if return_id else True
        else:
            with conn.cursor() as cur:
                cur.execute(query, args)
                last_id = cur.lastrowid
                return last_id if return_id else True
    finally:
        conn.close()

def init_db():
    conn, is_sqlite = get_db_connection()
    try:
        if is_sqlite:
            cur = conn.cursor()
            cur.executescript('''
                CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    username TEXT UNIQUE NOT NULL,
                    email TEXT UNIQUE NOT NULL,
                    password_hash TEXT NOT NULL,
                    bio TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                );

                CREATE TABLE IF NOT EXISTS user_profiles (
                    user_id INTEGER PRIMARY KEY,
                    preferred_families TEXT,
                    preferred_notes TEXT,
                    disliked_notes TEXT,
                    preferred_occasions TEXT,
                    preferred_seasons TEXT,
                    budget_min REAL DEFAULT 0,
                    budget_max REAL DEFAULT 350,
                    longevity_preference TEXT DEFAULT 'Long Lasting',
                    persona_title TEXT DEFAULT 'The Curious Connoisseur',
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
                );

                CREATE TABLE IF NOT EXISTS perfumes (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL,
                    brand TEXT NOT NULL,
                    concentration TEXT DEFAULT 'Eau de Parfum',
                    scent_family TEXT NOT NULL,
                    secondary_family TEXT,
                    gender TEXT DEFAULT 'Unisex',
                    price REAL NOT NULL,
                    bottle_size_ml INTEGER DEFAULT 100,
                    description TEXT,
                    top_notes TEXT,
                    middle_notes TEXT,
                    base_notes TEXT,
                    all_notes TEXT,
                    best_occasions TEXT,
                    best_seasons TEXT,
                    longevity_score REAL DEFAULT 4.0,
                    sillage_score REAL DEFAULT 4.0,
                    rating_avg REAL DEFAULT 4.50,
                    rating_count INTEGER DEFAULT 0,
                    image_url TEXT,
                    release_year INTEGER,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                );

                CREATE TABLE IF NOT EXISTS user_collections (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER NOT NULL,
                    perfume_id INTEGER NOT NULL,
                    collection_type TEXT NOT NULL,
                    notes TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE(user_id, perfume_id, collection_type),
                    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
                    FOREIGN KEY (perfume_id) REFERENCES perfumes(id) ON DELETE CASCADE
                );

                CREATE TABLE IF NOT EXISTS reviews (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER NOT NULL,
                    perfume_id INTEGER NOT NULL,
                    rating INTEGER NOT NULL,
                    longevity_rating TEXT DEFAULT 'Moderate',
                    sillage_rating TEXT DEFAULT 'Moderate',
                    season_vote TEXT DEFAULT 'All Season',
                    title TEXT,
                    content TEXT NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE(user_id, perfume_id),
                    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
                    FOREIGN KEY (perfume_id) REFERENCES perfumes(id) ON DELETE CASCADE
                );
            ''')
            conn.commit()
            cur.close()
            print("[DB] Initialized SQLite database tables successfully.")
        else:
            with conn.cursor() as cur:
                # Read schema.sql
                schema_path = os.path.join(os.path.dirname(__file__), 'schema.sql')
                with open(schema_path, 'r', encoding='utf-8') as f:
                    schema_sql = f.read()
                
                # Split and execute individual statements
                statements = [s.strip() for s in schema_sql.split(';') if s.strip()]
                for stmt in statements:
                    cur.execute(stmt)
                print("[DB] Initialized MySQL database schema successfully.")
    finally:
        conn.close()

if __name__ == '__main__':
    init_db()
