# ScentStory — Perfume Discovery Platform

> A personalized, luxury web platform for discovering fragrances based on scent preferences, occasions, performance, and budgets.

Built with **Python Flask**, **MySQL**, **JavaScript (ES6+)**, and a **multi-factor recommendation engine**.

---

## 🌟 Unique Features

### 1. 🧬 Interactive Fragrance Profile & Olfactory Archetype
- Step-by-step 5-question fragrance quiz evaluating preferred scent families, note accents, lifestyle occasions, budget range, and sillage expectations.
- Generates an evocative **Fragrance Archetype** (e.g. *The Nocturnal Gourmand*, *The Modern Romantic*, *The Forest Philosopher*, *The Sun-Drenched Minimalist*, *The Opulent Alchemist*).
- Calculates multi-factor match percentages (e.g., `98% Match`) for every fragrance in the catalog with tailored reasons.

### 2. 🌿 Dynamic Note & Family Filtering
- **Five Primary Note Families**: Floral, Woody, Fresh, Sweet & Gourmand, and Warm & Spicy.
- **Specific Ingredient Chips**: Multi-select filtering for Bergamot, Vanilla, Sandalwood, Lavender, Rose, Oud, Amber, Tonka Bean, Cedar, Coffee, Cinnamon, Marine, and more.
- **Interactive Budget Range Slider**: Real-time price threshold filtering ($50 – $500+).
- **Occasion & Gender Filters**: Filter by Date Night, Office, Everyday, Luxury Gala, or Vacation.
- **Instant Live Search**: Debounced search across names, brands, descriptions, and accords.

### 3. ⚖️ Side-by-Side Fragrance Comparison Matrix & Floating Dock
- Compare up to 4 flacons simultaneously.
- Deep visual comparison across:
  - Flacon imagery and bottle sizes
  - Price and **Price per mL**
  - **Scent Pyramid**: Opening Top Notes, Blooming Heart Notes, Base Drydown Notes
  - Skin Longevity & Projection Sillage meters
  - Best Occasions & Ideal Seasons
  - Community Rating & Profile Match Score
- **Persistent Floating Comparison Dock**: Add fragrances anywhere as you browse, dock keeps count and opens the comparison matrix with one click.

### 4. 🗄️ Curated Fragrance Shelves
- **Favorites Shelf**: Instant heart button to bookmark holy-grail scents.
- **Fragrance Wishlist**: Keep track of bottles you plan to purchase or sample next.
- **My Fragrance Wardrobe**: Catalog bottles you currently own in your personal collection.

### 5. ✍️ Community Reviews & Performance Ratings
- Star ratings (1 to 5 stars).
- Community votes on **Longevity** (*Weak*, *Moderate*, *Long-Lasting*, *Eternal (12h+)*).
- Community votes on **Sillage & Trail** (*Intimate*, *Moderate*, *Strong*, *Enormous*).
- **Seasonal Wear Votes** (*Spring*, *Summer*, *Autumn*, *Winter*, *All Season*).
- Verified scent collector badges.

### 6. 📊 User Dashboard
- Olfactory Archetype showcase banner with personality badges.
- Quick stats: Favorites count, Wishlist count, Bottles owned, Reviews posted.
- Shelf tabs to manage your fragrance wardrobe.
- Personalized recommendation carousel updated as your profile evolves.

---

## 💻 Tech Stack

- **Backend**: Python 3.12, Flask, Jinja2
- **Database**: MySQL (PyMySQL connector with dictionary cursors, auto-database creation, and automatic fallback to SQLite)
- **Frontend**: Vanilla JavaScript (ES6+), HTML5, CSS3 bespoke luxury dark/champagne aesthetic
- **Security**: Werkzeug password hashing, session cookies, input sanitization

---

## 🚀 Quick Start Guide

### 1. Prerequisites
- Python 3.10+ installed
- MySQL Server (Running on `localhost:3306`)

### 2. Install Dependencies
```bash
python -m pip install -r requirements.txt
```

### 3. Configure Database (.env)
Edit `.env` (or use defaults in `config.py`):
```env
DB_HOST=localhost
DB_PORT=3306
DB_USER=root
DB_PASSWORD=root
DB_NAME=scentstory_db
SECRET_KEY=scentstory_lux_secret_key_2026_discovery
```

### 4. Initialize & Seed Database
Run the seed script to create tables and populate 24+ iconic perfumes (Baccarat Rouge 540, Santal 33, Tobacco Vanille, Delina, Sauvage, Aventus, etc.) and demo accounts:
```bash
python seed_data.py
```

### 5. Run the Application
```bash
python app.py
```
Open your browser and navigate to:
```
http://127.0.0.1:5000
```

---

## 🔑 Demo Accounts

You can log in immediately using the pre-seeded demo accounts:

| Username | Password | Fragrance Archetype |
| :--- | :--- | :--- |
| `scent_curator` | `password123` | *The Nocturnal Connoisseur* (Woody, Spicy, Sweet) |
| `aria_bloom` | `password123` | *The Sun-Drenched Minimalist* (Floral, Fresh) |

Or register a new account and take the **Fragrance Quiz**!

---

## 🧪 Running Automated Tests
Run the comprehensive test suite verifying all routes, APIs, recommendations, and database transactions:
```bash
python test_app.py
```
