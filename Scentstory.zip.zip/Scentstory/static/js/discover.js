// ScentStory Discovery & Dynamic Filters
document.addEventListener('DOMContentLoaded', () => {
    initFilters();
});

let activeFamily = '';
let activeNotes = new Set();
let activeGender = 'all';
let activeOccasion = '';
let activeMaxPrice = 500;
let activeSort = 'popular';
let searchQuery = '';

function initFilters() {
    const searchInput = document.getElementById('discoverSearchInput');
    const sortSelect = document.getElementById('discoverSortSelect');
    const priceSlider = document.getElementById('priceRangeSlider');
    const priceDisplay = document.getElementById('maxPriceDisplay');
    const resetBtn = document.getElementById('resetFiltersBtn');

    // Read URL initial params
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('family')) {
        activeFamily = urlParams.get('family');
        document.querySelectorAll(`.family-chip[data-family="${activeFamily}"]`).forEach(c => c.classList.add('active'));
    }
    if (urlParams.get('note')) {
        const note = urlParams.get('note');
        activeNotes.add(note);
        document.querySelectorAll(`.note-chip[data-note="${note}"]`).forEach(c => c.classList.add('active'));
    }
    if (urlParams.get('q')) {
        searchQuery = urlParams.get('q');
        if (searchInput) searchInput.value = searchQuery;
    }

    // Family filter chips
    document.querySelectorAll('.family-chip').forEach(chip => {
        chip.addEventListener('click', () => {
            const fam = chip.dataset.family;
            if (activeFamily === fam) {
                activeFamily = '';
                chip.classList.remove('active');
            } else {
                document.querySelectorAll('.family-chip').forEach(c => c.classList.remove('active'));
                activeFamily = fam;
                chip.classList.add('active');
            }
            fetchFilteredPerfumes();
        });
    });

    // Note filter chips (Multi-select)
    document.querySelectorAll('.note-chip').forEach(chip => {
        chip.addEventListener('click', () => {
            const note = chip.dataset.note;
            if (activeNotes.has(note)) {
                activeNotes.delete(note);
                chip.classList.remove('active');
            } else {
                activeNotes.add(note);
                chip.classList.add('active');
            }
            fetchFilteredPerfumes();
        });
    });

    // Gender radio chips
    document.querySelectorAll('.gender-chip').forEach(chip => {
        chip.addEventListener('click', () => {
            document.querySelectorAll('.gender-chip').forEach(c => c.classList.remove('active'));
            activeGender = chip.dataset.gender;
            chip.classList.add('active');
            fetchFilteredPerfumes();
        });
    });

    // Occasion chips
    document.querySelectorAll('.occasion-chip').forEach(chip => {
        chip.addEventListener('click', () => {
            const occ = chip.dataset.occasion;
            if (activeOccasion === occ) {
                activeOccasion = '';
                chip.classList.remove('active');
            } else {
                document.querySelectorAll('.occasion-chip').forEach(c => c.classList.remove('active'));
                activeOccasion = occ;
                chip.classList.add('active');
            }
            fetchFilteredPerfumes();
        });
    });

    // Price range slider
    if (priceSlider) {
        priceSlider.addEventListener('input', (e) => {
            activeMaxPrice = e.target.value;
            if (priceDisplay) priceDisplay.textContent = `$${activeMaxPrice}`;
        });
        priceSlider.addEventListener('change', () => {
            fetchFilteredPerfumes();
        });
    }

    // Search input with debounce
    if (searchInput) {
        let debounceTimer;
        searchInput.addEventListener('input', (e) => {
            clearTimeout(debounceTimer);
            debounceTimer = setTimeout(() => {
                searchQuery = e.target.value.trim();
                fetchFilteredPerfumes();
            }, 300);
        });
    }

    // Sort select
    if (sortSelect) {
        sortSelect.addEventListener('change', (e) => {
            activeSort = e.target.value;
            fetchFilteredPerfumes();
        });
    }

    // Reset filters
    if (resetBtn) {
        resetBtn.addEventListener('click', () => {
            activeFamily = '';
            activeNotes.clear();
            activeGender = 'all';
            activeOccasion = '';
            activeMaxPrice = 500;
            searchQuery = '';
            activeSort = 'popular';

            if (searchInput) searchInput.value = '';
            if (priceSlider) priceSlider.value = 500;
            if (priceDisplay) priceDisplay.textContent = '$500';
            if (sortSelect) sortSelect.value = 'popular';

            document.querySelectorAll('.filter-chip').forEach(c => c.classList.remove('active'));
            document.querySelectorAll('.gender-chip[data-gender="all"]').forEach(c => c.classList.add('active'));

            fetchFilteredPerfumes();
        });
    }

    // Initial fetch
    fetchFilteredPerfumes();
}

async function fetchFilteredPerfumes() {
    const grid = document.getElementById('discoverPerfumesGrid');
    const countLabel = document.getElementById('resultsCount');

    if (!grid) return;

    grid.innerHTML = `
        <div style="grid-column: 1/-1; text-align: center; padding: 3rem 0; color: var(--text-muted);">
            <i class="fa-solid fa-spinner fa-spin fa-2x" style="color: var(--gold-primary); margin-bottom: 1rem;"></i>
            <p>Searching olfactory archives...</p>
        </div>
    `;

    try {
        const params = new URLSearchParams();
        if (searchQuery) params.append('q', searchQuery);
        if (activeFamily) params.append('family', activeFamily);
        if (activeNotes.size > 0) {
            params.append('notes', Array.from(activeNotes).join(','));
        }
        if (activeGender && activeGender !== 'all') params.append('gender', activeGender);
        if (activeOccasion) params.append('occasion', activeOccasion);
        if (activeMaxPrice < 500) params.append('max_price', activeMaxPrice);
        if (activeSort) params.append('sort_by', activeSort);

        const res = await fetch(`/api/perfumes/filter?${params.toString()}`);
        const data = await res.json();

        if (data.status === 'success') {
            if (countLabel) countLabel.textContent = `${data.count} Fragrances`;

            if (data.count === 0) {
                grid.innerHTML = `
                    <div style="grid-column: 1/-1; text-align: center; padding: 4rem 1rem; background: var(--bg-card); border-radius: var(--radius-md); border: 1px dashed var(--border-subtle);">
                        <i class="fa-solid fa-wind fa-3x" style="color: var(--text-dim); margin-bottom: 1rem;"></i>
                        <h3 class="serif-font" style="margin-bottom: 0.5rem;">No exact scent match found</h3>
                        <p style="color: var(--text-muted); max-width: 450px; margin: 0 auto 1.5rem;">Try widening your budget, toggling off specific notes, or exploring another fragrance family.</p>
                        <button class="btn btn-outline" onclick="document.getElementById('resetFiltersBtn').click()">Clear All Filters</button>
                    </div>
                `;
                return;
            }

            grid.innerHTML = data.perfumes.map(p => renderPerfumeCard(p)).join('');
            attachCardEventListeners();
            updateCompareButtons();
        }
    } catch (err) {
        console.error('Error fetching perfumes:', err);
        grid.innerHTML = `<p style="grid-column: 1/-1; text-align: center; color: #ef9a9a;">Error loading fragrances. Please try again.</p>`;
    }
}

function renderPerfumeCard(perfume) {
    const familyClass = (perfume.scent_family || '').toLowerCase();
    const matchBadge = perfume.match_score 
        ? `<span class="match-badge"><i class="fa-solid fa-sparkles"></i> ${perfume.match_score}% Match</span>` 
        : '';

    return `
        <div class="perfume-card" data-id="${perfume.id}">
            <div class="perfume-img-wrap">
                <a href="/perfume/${perfume.id}">
                    <img src="${perfume.image_url}" alt="${perfume.name}" class="perfume-img" loading="lazy">
                </a>
                <div class="perfume-badges-overlay">
                    ${matchBadge}
                    <span class="family-badge ${familyClass}">${perfume.scent_family}</span>
                </div>
                <div class="perfume-actions-overlay">
                    <button class="btn-icon btn-fav-toggle" data-id="${perfume.id}" title="Save to Favorites">
                        <i class="fa-solid fa-heart"></i>
                    </button>
                    <button class="btn-icon btn-wish-toggle" data-id="${perfume.id}" title="Add to Wishlist">
                        <i class="fa-solid fa-bookmark"></i>
                    </button>
                </div>
            </div>
            <div class="perfume-body">
                <div class="perfume-brand">${perfume.brand}</div>
                <h3 class="perfume-title">
                    <a href="/perfume/${perfume.id}">${perfume.name}</a>
                </h3>
                <div class="perfume-notes-summary">
                    ${perfume.all_notes || perfume.top_notes || ''}
                </div>
                <div class="perfume-meta-row">
                    <div class="perfume-price">$${parseFloat(perfume.price).toFixed(0)}</div>
                    <div class="perfume-rating">
                        <i class="fa-solid fa-star"></i>
                        <span>${parseFloat(perfume.rating_avg).toFixed(1)}</span>
                        <span class="rating-count-text">(${perfume.rating_count})</span>
                    </div>
                </div>
                <div style="margin-top: 1rem; display: flex; gap: 0.5rem;">
                    <a href="/perfume/${perfume.id}" class="btn btn-outline" style="flex: 1; padding: 0.5rem; font-size: 0.85rem;">
                        View Notes
                    </a>
                    <button class="btn btn-outline btn-compare-toggle" data-id="${perfume.id}" 
                            data-name="${perfume.name}" data-brand="${perfume.brand}" data-image="${perfume.image_url}"
                            style="padding: 0.5rem 0.85rem; font-size: 0.85rem;">
                        <i class="fa-solid fa-code-compare"></i> Compare
                    </button>
                </div>
            </div>
        </div>
    `;
}

function attachCardEventListeners() {
    // Favorite button
    document.querySelectorAll('.btn-fav-toggle').forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.preventDefault();
            const id = parseInt(btn.dataset.id);
            toggleCollection(id, 'favorites', btn);
        });
    });

    // Wishlist button
    document.querySelectorAll('.btn-wish-toggle').forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.preventDefault();
            const id = parseInt(btn.dataset.id);
            toggleCollection(id, 'wishlist', btn);
        });
    });

    // Compare button
    document.querySelectorAll('.btn-compare-toggle').forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.preventDefault();
            const perfume = {
                id: parseInt(btn.dataset.id),
                name: btn.dataset.name,
                brand: btn.dataset.brand,
                image_url: btn.dataset.image
            };
            toggleComparePerfume(perfume);
        });
    });
}
