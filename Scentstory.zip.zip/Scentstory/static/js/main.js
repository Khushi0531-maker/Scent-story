// ScentStory Main JavaScript
document.addEventListener('DOMContentLoaded', () => {
    initAlertDismiss();
    initCompareDock();
    updateCompareDock();
});

// Dismiss alert banners
function initAlertDismiss() {
    document.querySelectorAll('.alert .close-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const alert = e.target.closest('.alert');
            if (alert) {
                alert.style.opacity = '0';
                setTimeout(() => alert.remove(), 250);
            }
        });
    });
}

// Compare Dock Management
const COMPARE_KEY = 'scentstory_compare_list';

function getCompareList() {
    try {
        const stored = localStorage.getItem(COMPARE_KEY);
        return stored ? JSON.parse(stored) : [];
    } catch (e) {
        return [];
    }
}

function saveCompareList(list) {
    localStorage.setItem(COMPARE_KEY, JSON.stringify(list));
    updateCompareDock();
    updateCompareButtons();
}

function toggleComparePerfume(perfume) {
    let list = getCompareList();
    const existingIndex = list.findIndex(p => p.id === perfume.id);

    if (existingIndex > -1) {
        list.splice(existingIndex, 1);
        showToast(`Removed ${perfume.name} from comparison.`, 'info');
    } else {
        if (list.length >= 4) {
            showToast('You can compare a maximum of 4 fragrances at a time.', 'warning');
            return false;
        }
        list.push(perfume);
        showToast(`Added ${perfume.name} to comparison!`, 'success');
    }

    saveCompareList(list);
    return true;
}

function updateCompareDock() {
    const list = getCompareList();
    const dock = document.getElementById('compareDock');
    const dockThumbs = document.getElementById('dockThumbs');
    const dockCount = document.getElementById('dockCount');
    const dockBtn = document.getElementById('dockCompareBtn');

    if (!dock) return;

    if (list.length > 0) {
        dock.classList.add('visible');
        if (dockCount) dockCount.textContent = list.length;
        if (dockThumbs) {
            dockThumbs.innerHTML = list.map(item => `
                <div class="dock-thumb" title="${item.brand} - ${item.name}">
                    <img src="${item.image_url}" alt="${item.name}">
                </div>
            `).join('');
        }
        if (dockBtn) {
            const ids = list.map(item => item.id).join(',');
            dockBtn.href = `/compare?ids=${ids}`;
        }
    } else {
        dock.classList.remove('visible');
    }
}

function updateCompareButtons() {
    const list = getCompareList();
    const ids = new Set(list.map(p => p.id));

    document.querySelectorAll('.btn-compare-toggle').forEach(btn => {
        const pId = parseInt(btn.dataset.id);
        if (ids.has(pId)) {
            btn.classList.add('active');
            btn.innerHTML = '<i class="fa-solid fa-check"></i> In Compare';
        } else {
            btn.classList.remove('active');
            btn.innerHTML = '<i class="fa-solid fa-code-compare"></i> Compare';
        }
    });
}

function clearCompareList() {
    localStorage.removeItem(COMPARE_KEY);
    updateCompareDock();
    updateCompareButtons();
    showToast('Comparison list cleared.', 'info');
}

// Global Toast Notification
function showToast(message, type = 'info') {
    let container = document.getElementById('toastContainer');
    if (!container) {
        container = document.createElement('div');
        container.id = 'toastContainer';
        container.style.position = 'fixed';
        container.style.top = '24px';
        container.style.right = '24px';
        container.style.zIndex = '9999';
        container.style.display = 'flex';
        container.style.flexDirection = 'column';
        container.style.gap = '10px';
        document.body.appendChild(container);
    }

    const toast = document.createElement('div');
    toast.className = `alert alert-${type}`;
    toast.style.boxShadow = '0 10px 25px rgba(0,0,0,0.4)';
    toast.style.minWidth = '260px';
    toast.innerHTML = `
        <span>${message}</span>
        <button class="close-btn" style="margin-left: 12px; background: none; border: none; cursor: pointer; color: inherit;">&times;</button>
    `;

    container.appendChild(toast);

    toast.querySelector('.close-btn').addEventListener('click', () => {
        toast.remove();
    });

    setTimeout(() => {
        if (toast.parentNode) {
            toast.style.opacity = '0';
            toast.style.transition = 'opacity 0.3s ease';
            setTimeout(() => toast.remove(), 300);
        }
    }, 3500);
}

// Global Collection Toggle (Favorites, Wishlist, Wardrobe)
async function toggleCollection(perfumeId, collectionType, btnElement) {
    try {
        const resp = await fetch('/api/collection/toggle', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ perfume_id: perfumeId, collection_type: collectionType })
        });

        if (resp.status === 401 || resp.redirected) {
            window.location.href = '/login';
            return;
        }

        const data = await resp.json();
        if (data.status === 'success') {
            if (data.action === 'added') {
                btnElement.classList.add('active');
                showToast(`Added to your ${collectionType}!`, 'success');
            } else {
                btnElement.classList.remove('active');
                showToast(`Removed from your ${collectionType}.`, 'info');
            }
        }
    } catch (err) {
        console.error('Error toggling collection:', err);
    }
}
