// ScentStory Fragrance Profile Builder / Quiz Flow
document.addEventListener('DOMContentLoaded', () => {
    initQuiz();
});

let currentStep = 1;
const totalSteps = 5;

const quizAnswers = {
    families: [],
    notes: [],
    occasions: [],
    seasons: [],
    budget_min: 0,
    budget_max: 350,
    longevity: 'Long Lasting'
};

function initQuiz() {
    const nextBtn = document.getElementById('quizNextBtn');
    const prevBtn = document.getElementById('quizPrevBtn');
    const submitBtn = document.getElementById('quizSubmitBtn');
    const restartBtn = document.getElementById('quizRestartBtn');
    const budgetSlider = document.getElementById('quizBudgetSlider');
    const budgetDisplay = document.getElementById('quizBudgetDisplay');

    // Option cards toggle (multi-select for families, notes, occasions, seasons)
    document.querySelectorAll('.quiz-option-card').forEach(card => {
        card.addEventListener('click', () => {
            const category = card.dataset.category;
            const value = card.dataset.value;
            const isSingle = card.dataset.single === 'true';

            if (isSingle) {
                // Single select
                document.querySelectorAll(`.quiz-option-card[data-category="${category}"]`).forEach(c => c.classList.remove('selected'));
                card.classList.add('selected');
                quizAnswers[category] = value;
            } else {
                // Multi select
                if (card.classList.contains('selected')) {
                    card.classList.remove('selected');
                    quizAnswers[category] = quizAnswers[category].filter(v => v !== value);
                } else {
                    card.classList.add('selected');
                    if (!quizAnswers[category].includes(value)) {
                        quizAnswers[category].push(value);
                    }
                }
            }
        });
    });

    // Budget slider
    if (budgetSlider) {
        budgetSlider.addEventListener('input', (e) => {
            quizAnswers.budget_max = parseInt(e.target.value);
            if (budgetDisplay) budgetDisplay.textContent = `$${quizAnswers.budget_max}`;
        });
    }

    if (nextBtn) {
        nextBtn.addEventListener('click', () => {
            if (validateStep(currentStep)) {
                if (currentStep < totalSteps) {
                    currentStep++;
                    updateQuizView();
                }
            }
        });
    }

    if (prevBtn) {
        prevBtn.addEventListener('click', () => {
            if (currentStep > 1) {
                currentStep--;
                updateQuizView();
            }
        });
    }

    if (submitBtn) {
        submitBtn.addEventListener('click', submitQuiz);
    }

    if (restartBtn) {
        restartBtn.addEventListener('click', resetQuiz);
    }
}

function validateStep(step) {
    if (step === 1 && quizAnswers.families.length === 0) {
        showToast('Please select at least one fragrance family to proceed.', 'warning');
        return false;
    }
    if (step === 2 && quizAnswers.notes.length === 0) {
        showToast('Please select at least 2 favorite note accents.', 'warning');
        return false;
    }
    if (step === 3 && quizAnswers.occasions.length === 0) {
        showToast('Please pick at least one occasion you wear perfume for.', 'warning');
        return false;
    }
    return true;
}

function updateQuizView() {
    // Hide all steps, show current
    document.querySelectorAll('.quiz-step').forEach(stepEl => {
        stepEl.classList.remove('active');
        if (parseInt(stepEl.dataset.step) === currentStep) {
            stepEl.classList.add('active');
        }
    });

    // Progress bar
    const progressEl = document.getElementById('quizProgressBar');
    if (progressEl) {
        const percentage = (currentStep / totalSteps) * 100;
        progressEl.style.width = `${percentage}%`;
    }

    // Step counter
    const counterEl = document.getElementById('quizStepIndicator');
    if (counterEl) {
        counterEl.textContent = `Step ${currentStep} of ${totalSteps}`;
    }

    // Buttons visibility
    const prevBtn = document.getElementById('quizPrevBtn');
    const nextBtn = document.getElementById('quizNextBtn');
    const submitBtn = document.getElementById('quizSubmitBtn');

    if (prevBtn) prevBtn.style.display = currentStep > 1 ? 'inline-flex' : 'none';
    if (nextBtn) nextBtn.style.display = currentStep < totalSteps ? 'inline-flex' : 'none';
    if (submitBtn) submitBtn.style.display = currentStep === totalSteps ? 'inline-flex' : 'none';
}

async function submitQuiz() {
    const loadingEl = document.getElementById('quizLoading');
    const stepsWrap = document.getElementById('quizStepsWrap');
    const resultsWrap = document.getElementById('quizResultsWrap');

    if (stepsWrap) stepsWrap.style.display = 'none';
    if (loadingEl) loadingEl.style.display = 'block';

    try {
        const res = await fetch('/api/quiz-results', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(quizAnswers)
        });

        const data = await res.json();
        if (data.status === 'success') {
            if (loadingEl) loadingEl.style.display = 'none';
            if (resultsWrap) {
                resultsWrap.style.display = 'block';
                renderQuizResults(data.persona, data.matches);
            }
        }
    } catch (err) {
        console.error('Quiz submission error:', err);
        showToast('Error calculating your fragrance match. Please try again.', 'danger');
        if (loadingEl) loadingEl.style.display = 'none';
        if (stepsWrap) stepsWrap.style.display = 'block';
    }
}

function renderQuizResults(persona, matches) {
    const personaTitle = document.getElementById('resultPersonaTitle');
    const personaSubtitle = document.getElementById('resultPersonaSubtitle');
    const personaDesc = document.getElementById('resultPersonaDesc');
    const personaIcon = document.getElementById('resultPersonaIcon');
    const matchesGrid = document.getElementById('quizMatchesGrid');

    if (personaTitle) personaTitle.textContent = persona.title;
    if (personaSubtitle) personaSubtitle.textContent = persona.subtitle;
    if (personaDesc) personaDesc.textContent = persona.desc;
    if (personaIcon) personaIcon.className = `fa-solid ${persona.badge}`;

    if (matchesGrid) {
        matchesGrid.innerHTML = matches.map(p => `
            <div class="perfume-card">
                <div class="perfume-img-wrap">
                    <a href="/perfume/${p.id}">
                        <img src="${p.image_url}" alt="${p.name}" class="perfume-img">
                    </a>
                    <div class="perfume-badges-overlay">
                        <span class="match-badge" style="background: rgba(212, 175, 55, 0.9); color: #12100e;">
                            <i class="fa-solid fa-sparkles"></i> ${p.match_score}% Match
                        </span>
                        <span class="family-badge">${p.scent_family}</span>
                    </div>
                </div>
                <div class="perfume-body">
                    <div class="perfume-brand">${p.brand}</div>
                    <h3 class="perfume-title">
                        <a href="/perfume/${p.id}">${p.name}</a>
                    </h3>
                    <ul style="list-style: none; margin: 0.5rem 0 1rem; font-size: 0.8rem; color: var(--gold-light);">
                        ${(p.match_reasons || []).map(r => `<li><i class="fa-solid fa-check" style="margin-right: 4px;"></i> ${r}</li>`).join('')}
                    </ul>
                    <div class="perfume-meta-row">
                        <div class="perfume-price">$${parseFloat(p.price).toFixed(0)}</div>
                        <a href="/perfume/${p.id}" class="btn btn-primary" style="padding: 0.45rem 1rem; font-size: 0.82rem;">
                            View Scent Profile
                        </a>
                    </div>
                </div>
            </div>
        `).join('');
    }
}

function resetQuiz() {
    currentStep = 1;
    quizAnswers.families = [];
    quizAnswers.notes = [];
    quizAnswers.occasions = [];
    quizAnswers.seasons = [];
    quizAnswers.budget_max = 350;

    document.querySelectorAll('.quiz-option-card').forEach(c => c.classList.remove('selected'));
    const stepsWrap = document.getElementById('quizStepsWrap');
    const resultsWrap = document.getElementById('quizResultsWrap');

    if (stepsWrap) stepsWrap.style.display = 'block';
    if (resultsWrap) resultsWrap.style.display = 'none';

    updateQuizView();
}
