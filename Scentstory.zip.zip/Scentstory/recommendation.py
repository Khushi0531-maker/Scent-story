import math
from db import query_db

def _parse_list(val):
    if not val:
        return []
    if isinstance(val, list):
        return [str(x).strip().lower() for x in val if x]
    return [x.strip().lower() for x in str(val).split(',') if x.strip()]

def determine_fragrance_persona(families, notes):
    """
    Determines an evocative Fragrance Personality Archetype based on selected scent families & notes.
    """
    fam_set = set(_parse_list(families))
    note_set = set(_parse_list(notes))

    if ('sweet' in fam_set or 'gourmand' in fam_set) and ('spicy' in fam_set or 'tobacco' in note_set or 'cinnamon' in note_set):
        return {
            "title": "The Nocturnal Gourmand",
            "subtitle": "Warm, Decadent & Intoxicating",
            "badge": "fa-moon",
            "desc": "Drawn to rich vanillas, smoky spices, and intoxicating amber accords. You make a lingering, magnetic impression wherever you wander after twilight."
        }
    elif 'woody' in fam_set and ('fresh' in fam_set or 'green' in fam_set or 'cedar' in note_set or 'sandalwood' in note_set):
        return {
            "title": "The Forest Philosopher",
            "subtitle": "Earthy, Contemplative & Timeless",
            "badge": "fa-tree",
            "desc": "Grounding and serene. You appreciate the quiet luxury of Australian sandalwood, crisp cedar bark, cardamom, and mossy mountain breezes."
        }
    elif 'floral' in fam_set and ('fresh' in fam_set or 'rose' in note_set or 'peony' in note_set):
        return {
            "title": "The Modern Romantic",
            "subtitle": "Radiant, Luminous & Graceful",
            "badge": "fa-feather",
            "desc": "A lover of contemporary florals, lush petals, sparkling lychee, and whisper-soft musks. Your sillage is effortless poetry in motion."
        }
    elif 'fresh' in fam_set or 'citrus' in fam_set or 'aquatic' in note_set or 'bergamot' in note_set:
        return {
            "title": "The Sun-Drenched Minimalist",
            "subtitle": "Crisp, Oceanic & Invigorating",
            "badge": "fa-sun",
            "desc": "Driven by clean lines, sea salt spray, and Mediterranean citrus groves. You value understated confidence and pure, breathless freshness."
        }
    elif 'spicy' in fam_set or 'oriental' in fam_set or 'oud' in note_set or 'amber' in note_set:
        return {
            "title": "The Opulent Alchemist",
            "subtitle": "Rare, Enigmatic & Majestic",
            "badge": "fa-gem",
            "desc": "Unapologetically bold. You gravitate toward precious resinous balsams, aged agarwood, and exotic saffron that command immediate reverence."
        }
    else:
        return {
            "title": "The Curious Connoisseur",
            "subtitle": "Eclectic, Balanced & Distinctive",
            "badge": "fa-compass",
            "desc": "An adventurous palate that refuses to be boxed into one family. You love layering unexpected accords and finding hidden olfactory gems."
        }

def calculate_perfume_match(perfume, profile):
    """
    Calculates a multi-factor compatibility percentage (30-99%) and matching reasons.
    """
    score = 0
    max_score = 100
    reasons = []

    pref_families = _parse_list(profile.get('preferred_families', ''))
    pref_notes = _parse_list(profile.get('preferred_notes', ''))
    disliked_notes = _parse_list(profile.get('disliked_notes', ''))
    pref_occasions = _parse_list(profile.get('preferred_occasions', ''))
    pref_seasons = _parse_list(profile.get('preferred_seasons', ''))
    
    budget_min = float(profile.get('budget_min', 0) or 0)
    budget_max = float(profile.get('budget_max', 350) or 350)
    price = float(perfume.get('price', 0) or 0)

    perf_fam = (perfume.get('scent_family') or '').lower()
    perf_sec_fam = (perfume.get('secondary_family') or '').lower()
    perf_notes_all = _parse_list(perfume.get('all_notes', ''))
    perf_base_notes = _parse_list(perfume.get('base_notes', ''))
    perf_occasions = _parse_list(perfume.get('best_occasions', ''))
    perf_seasons = _parse_list(perfume.get('best_seasons', ''))

    # 1. Scent Family Matching (up to 35 pts)
    fam_score = 0
    if pref_families:
        if perf_fam in pref_families:
            fam_score += 25
            reasons.append(f"Features your favorite {perf_fam.capitalize()} family")
        if perf_sec_fam and perf_sec_fam in pref_families:
            fam_score += 10
            if perf_sec_fam != perf_fam:
                reasons.append(f"Complemented by {perf_sec_fam.capitalize()} accords")
        score += min(35, fam_score)
    else:
        score += 25  # Neutral baseline if unselected

    # 2. Notes Overlap & Dislike Penalty (up to 30 pts)
    note_matches = []
    if pref_notes:
        for n in pref_notes:
            # Check if note keyword appears in perfume notes
            if any(n in pn for pn in perf_notes_all):
                note_matches.append(n)
                # Extra weight for drydown base note
                if any(n in bn for bn in perf_base_notes):
                    score += 8
                else:
                    score += 6
        
        score = min(30, score)
        if note_matches:
            display_notes = ", ".join([n.capitalize() for n in note_matches[:3]])
            reasons.append(f"Includes favorite notes: {display_notes}")
    else:
        score += 20

    # Dislike Penalty
    if disliked_notes:
        penalized = [d for d in disliked_notes if any(d in pn for pn in perf_notes_all)]
        if penalized:
            score -= (len(penalized) * 15)
            score = max(10, score)

    # 3. Occasions & Seasons Match (up to 20 pts)
    occ_score = 0
    if pref_occasions:
        occ_matches = [o for o in pref_occasions if any(o in po for po in perf_occasions)]
        if occ_matches:
            occ_score += min(10, len(occ_matches) * 5)
            reasons.append(f"Tailored for {occ_matches[0].capitalize()}")
    else:
        occ_score += 7

    if pref_seasons:
        season_matches = [s for s in pref_seasons if any(s in ps for ps in perf_seasons)]
        if season_matches:
            occ_score += min(10, len(season_matches) * 5)
    else:
        occ_score += 7
    score += occ_score

    # 4. Budget Match (up to 15 pts)
    if budget_max > 0:
        if budget_min <= price <= budget_max:
            score += 15
            reasons.append("Priced perfectly within your budget")
        elif price <= budget_max * 1.25:
            score += 8
        elif price < budget_min:
            score += 10
        else:
            score += 2
    else:
        score += 10

    # Longevity bonus
    long_pref = (profile.get('longevity_preference') or '').lower()
    perf_long = float(perfume.get('longevity_score') or 4.0)
    if 'beast' in long_pref and perf_long >= 4.7:
        score += 5
        reasons.append("Exceptional beast-mode longevity (12h+)")
    elif 'moderate' in long_pref and 3.5 <= perf_long <= 4.4:
        score += 5

    # Scale to 40% - 99% range
    normalized = int(round(40 + (min(score, max_score) / max_score) * 59))
    normalized = max(35, min(99, normalized))

    if not reasons:
        reasons.append("Harmonious scent balance with high community acclaim")

    return normalized, reasons[:3]

def get_recommendations_for_user(user_id=None, profile_data=None, limit=12):
    """
    Returns ranked perfume recommendations based on either user ID or transient quiz data.
    """
    profile = profile_data
    if user_id and not profile:
        profile = query_db("SELECT * FROM user_profiles WHERE user_id = %s", (user_id,), one=True)
    
    perfumes = query_db("SELECT * FROM perfumes")
    if not perfumes:
        return []

    if not profile:
        # Default sort by rating if no profile exists
        for p in perfumes:
            p['match_score'] = int(round((float(p['rating_avg']) / 5.0) * 100))
            p['match_reasons'] = ["Community Top Rated", f"Rated {p['rating_avg']} / 5"]
        perfumes.sort(key=lambda x: (x.get('rating_avg', 0), x.get('rating_count', 0)), reverse=True)
        return perfumes[:limit]

    results = []
    for p in perfumes:
        p_copy = dict(p)
        match_score, reasons = calculate_perfume_match(p_copy, profile)
        p_copy['match_score'] = match_score
        p_copy['match_reasons'] = reasons
        results.append(p_copy)

    # Sort descending by match score, then rating
    results.sort(key=lambda x: (x['match_score'], x['rating_avg']), reverse=True)
    return results[:limit]

def get_similar_perfumes(perfume_id, limit=4):
    """
    Finds 'Scent Twins' and alternative fragrances based on shared notes, family, and accords.
    """
    target = query_db("SELECT * FROM perfumes WHERE id = %s", (perfume_id,), one=True)
    if not target:
        return []

    all_perfumes = query_db("SELECT * FROM perfumes WHERE id != %s", (perfume_id,))
    target_notes = set(_parse_list(target.get('all_notes', '')))
    target_fam = (target.get('scent_family') or '').lower()
    target_sec_fam = (target.get('secondary_family') or '').lower()

    scored = []
    for p in all_perfumes:
        sim_score = 0
        p_notes = set(_parse_list(p.get('all_notes', '')))
        overlap = target_notes.intersection(p_notes)
        sim_score += len(overlap) * 15

        if (p.get('scent_family') or '').lower() == target_fam:
            sim_score += 25
        if (p.get('secondary_family') or '').lower() == target_sec_fam and target_sec_fam:
            sim_score += 15

        p_copy = dict(p)
        p_copy['shared_notes'] = [n.capitalize() for n in list(overlap)[:3]]
        p_copy['similarity_percentage'] = min(98, max(45, int(round(sim_score * 0.9))))
        scored.append((sim_score, p_copy))

    scored.sort(key=lambda x: x[0], reverse=True)
    return [item[1] for item in scored[:limit]]
