-- ScentStory Database Schema for MySQL

CREATE DATABASE IF NOT EXISTS scentstory_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE scentstory_db;

-- 1. Users Table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(120) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    bio TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2. Fragrance Profiles Table
CREATE TABLE IF NOT EXISTS user_profiles (
    user_id INT PRIMARY KEY,
    preferred_families TEXT,
    preferred_notes TEXT,
    disliked_notes TEXT,
    preferred_occasions TEXT,
    preferred_seasons TEXT,
    budget_min DECIMAL(10,2) DEFAULT 0,
    budget_max DECIMAL(10,2) DEFAULT 350,
    longevity_preference VARCHAR(50) DEFAULT 'Long Lasting',
    persona_title VARCHAR(120) DEFAULT 'The Curious Connoisseur',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 3. Perfumes Table
CREATE TABLE IF NOT EXISTS perfumes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    brand VARCHAR(100) NOT NULL,
    concentration VARCHAR(50) DEFAULT 'Eau de Parfum',
    scent_family VARCHAR(50) NOT NULL,
    secondary_family VARCHAR(50),
    gender VARCHAR(30) DEFAULT 'Unisex',
    price DECIMAL(10,2) NOT NULL,
    bottle_size_ml INT DEFAULT 100,
    description TEXT,
    top_notes TEXT,
    middle_notes TEXT,
    base_notes TEXT,
    all_notes TEXT,
    best_occasions TEXT,
    best_seasons TEXT,
    longevity_score DECIMAL(3,1) DEFAULT 4.0,
    sillage_score DECIMAL(3,1) DEFAULT 4.0,
    rating_avg DECIMAL(3,2) DEFAULT 4.50,
    rating_count INT DEFAULT 0,
    image_url VARCHAR(500),
    release_year INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_family (scent_family),
    INDEX idx_brand (brand),
    INDEX idx_price (price)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 4. User Collections Table (Favorites, Wishlist, Wardrobe)
CREATE TABLE IF NOT EXISTS user_collections (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    perfume_id INT NOT NULL,
    collection_type ENUM('wishlist', 'favorites', 'wardrobe') NOT NULL,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_user_perfume_col (user_id, perfume_id, collection_type),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (perfume_id) REFERENCES perfumes(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 5. Reviews Table
CREATE TABLE IF NOT EXISTS reviews (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    perfume_id INT NOT NULL,
    rating INT NOT NULL CHECK (rating >= 1 AND rating <= 5),
    longevity_rating VARCHAR(30) DEFAULT 'Moderate',
    sillage_rating VARCHAR(30) DEFAULT 'Moderate',
    season_vote VARCHAR(30) DEFAULT 'All Season',
    title VARCHAR(150),
    content TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_user_perfume_review (user_id, perfume_id),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (perfume_id) REFERENCES perfumes(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
