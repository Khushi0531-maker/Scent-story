import unittest
from app import app
from db import query_db
from recommendation import determine_fragrance_persona, calculate_perfume_match

class ScentStoryTestCase(unittest.TestCase):
    def setUp(self):
        self.app = app
        self.app.config['TESTING'] = True
        self.client = self.app.test_client()

    def test_homepage(self):
        response = self.client.get('/')
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'ScentStory', response.data)
        self.assertIn(b'Explore Scent Families', response.data)

    def test_discover_page(self):
        response = self.client.get('/discover')
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'Discover Fragrances', response.data)
        self.assertIn(b'Floral', response.data)
        self.assertIn(b'Woody', response.data)

    def test_api_filter_perfumes(self):
        # Filter by woody family
        response = self.client.get('/api/perfumes/filter?family=Woody')
        self.assertEqual(response.status_code, 200)
        data = response.get_json()
        self.assertEqual(data['status'], 'success')
        self.assertGreater(data['count'], 0)
        for p in data['perfumes']:
            self.assertTrue(
                p['scent_family'].lower() == 'woody' or (p['secondary_family'] and p['secondary_family'].lower() == 'woody')
            )

    def test_perfume_detail(self):
        # Retrieve first perfume
        p = query_db("SELECT id, name FROM perfumes LIMIT 1", one=True)
        self.assertIsNotNone(p)
        response = self.client.get(f"/perfume/{p['id']}")
        self.assertEqual(response.status_code, 200)
        self.assertIn(p['name'].encode('utf-8'), response.data)
        self.assertIn(b'Olfactory Scent Pyramid', response.data)

    def test_quiz_and_api(self):
        response = self.client.get('/quiz')
        self.assertEqual(response.status_code, 200)

        # Test quiz submission API
        payload = {
            "families": ["Woody", "Spicy"],
            "notes": ["Sandalwood", "Vanilla", "Tobacco"],
            "occasions": ["Date Night", "Luxury"],
            "seasons": ["Autumn", "Winter"],
            "budget_min": 100,
            "budget_max": 400,
            "longevity": "Beast Mode"
        }
        api_res = self.client.post('/api/quiz-results', json=payload)
        self.assertEqual(api_res.status_code, 200)
        data = api_res.get_json()
        self.assertEqual(data['status'], 'success')
        self.assertIn('persona', data)
        self.assertIn('matches', data)
        self.assertGreater(len(data['matches']), 0)
        # Check that top match has high match score
        top_match = data['matches'][0]
        self.assertGreaterEqual(top_match['match_score'], 70)

    def test_compare_page(self):
        p1 = query_db("SELECT id FROM perfumes LIMIT 1", one=True)
        response = self.client.get(f"/compare?ids={p1['id']}")
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'Fragrance Comparison Matrix', response.data)

    def test_fragrance_persona_archetypes(self):
        p1 = determine_fragrance_persona('Sweet,Spicy', 'Vanilla,Tobacco')
        self.assertEqual(p1['title'], 'The Nocturnal Gourmand')

        p2 = determine_fragrance_persona('Woody,Fresh', 'Sandalwood,Cedar')
        self.assertEqual(p2['title'], 'The Forest Philosopher')

        p3 = determine_fragrance_persona('Fresh', 'Bergamot,Marine')
        self.assertEqual(p3['title'], 'The Sun-Drenched Minimalist')

    def test_user_flow_and_collections(self):
        # 1. Login with demo account
        login_res = self.client.post('/login', data={
            'username_or_email': 'scent_curator',
            'password': 'password123'
        }, follow_redirects=True)
        self.assertEqual(login_res.status_code, 200)
        self.assertIn(b'Dashboard', login_res.data)

        # 2. View dashboard
        dash_res = self.client.get('/dashboard')
        self.assertEqual(dash_res.status_code, 200)
        self.assertIn(b'Welcome, scent_curator', dash_res.data)

        # 3. Toggle collection via API
        p = query_db("SELECT id FROM perfumes LIMIT 1", one=True)
        toggle_res = self.client.post('/api/collection/toggle', json={
            'perfume_id': p['id'],
            'collection_type': 'wishlist'
        })
        self.assertEqual(toggle_res.status_code, 200)
        data = toggle_res.get_json()
        self.assertEqual(data['status'], 'success')

        # 4. View collections shelf
        shelf_res = self.client.get('/collections?tab=wishlist')
        self.assertEqual(shelf_res.status_code, 200)
        self.assertIn(b'My Fragrance Shelves', shelf_res.data)

if __name__ == '__main__':
    unittest.main()
