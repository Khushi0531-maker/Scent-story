import os
from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
from werkzeug.security import generate_password_hash, check_password_hash
from functools import wraps

from config import Config
from db import query_db, execute_db, init_db
from recommendation import (
    get_recommendations_for_user,
    get_similar_perfumes,
    calculate_perfume_match,
    determine_fragrance_persona
)

app = Flask(__name__)
app.config.from_object(Config)

# Ensure DB initialized on startup
try:
    init_db()
except Exception as e:
    print(f"[App Init Warning] DB initialization error: {e}")

# Helper decorator for login required
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash("Please sign in to access your personal fragrance space.", "info")
            return redirect(url_for('login', next=request.url))
        return f(*args, **kwargs)
    return decorated_function

# Context processor for global user data
@app.context_processor
def inject_global_data():
    current_user = None
    user_collections_map = {'favorites': [], 'wishlist': [], 'wardrobe': []}
    if 'user_id' in session:
        current_user = query_db("SELECT id, username, email FROM users WHERE id = %s", (session['user_id'],), one=True)
        cols = query_db("SELECT perfume_id, collection_type FROM user_collections WHERE user_id = %s", (session['user_id'],))
        for c in cols:
            user_collections_map[c['collection_type']].append(c['perfume_id'])
    
    return {
        'current_user': current_user,
        'user_collections': user_collections_map
    }

# --- ROUTES ---

@app.route('/')
def index():
    user_id = session.get('user_id')
    user_profile = None
    if user_id:
        user_profile = query_db("SELECT * FROM user_profiles WHERE user_id = %s", (user_id,), one=True)

    recommendations = get_recommendations_for_user(user_id=user_id, limit=8)
    trending = query_db("SELECT * FROM perfumes ORDER BY rating_avg DESC, rating_count DESC LIMIT 6")
    new_arrivals = query_db("SELECT * FROM perfumes ORDER BY release_year DESC LIMIT 6")

    # Fragrance Persona preview if logged in
    persona = None
    if user_profile and user_profile.get('preferred_families'):
        persona = determine_fragrance_persona(
            user_profile['preferred_families'],
            user_profile.get('preferred_notes', '')
        )

    return render_template(
        'index.html',
        recommendations=recommendations,
        trending=trending,
        new_arrivals=new_arrivals,
        user_profile=user_profile,
        persona=persona
    )

@app.route('/discover')
def discover():
    # Pass all unique scent families and common notes for filters
    families = ['Floral', 'Woody', 'Fresh', 'Sweet', 'Spicy']
    popular_notes = [
        'Vanilla', 'Sandalwood', 'Bergamot', 'Rose', 'Oud', 'Amber', 
        'Lavender', 'Jasmine', 'Tonka Bean', 'Pink Pepper', 'Cedar', 
        'Patchouli', 'Coconut', 'Cinnamon', 'Leather', 'Incense'
    ]
    brands = query_db("SELECT DISTINCT brand FROM perfumes ORDER BY brand ASC")
    brands_list = [b['brand'] for b in brands]
    
    # Initial query parameters
    selected_family = request.args.get('family', '')
    selected_note = request.args.get('note', '')
    search_query = request.args.get('q', '')

    return render_template(
        'discover.html',
        families=families,
        popular_notes=popular_notes,
        brands=brands_list,
        selected_family=selected_family,
        selected_note=selected_note,
        search_query=search_query
    )

@app.route('/api/perfumes/filter')
def api_filter_perfumes():
    q = request.args.get('q', '').strip()
    family = request.args.get('family', '').strip()
    secondary_family = request.args.get('secondary_family', '').strip()
    notes = request.args.getlist('notes[]') or request.args.get('notes', '').split(',')
    notes = [n.strip() for n in notes if n.strip()]
    gender = request.args.get('gender', '').strip()
    occasion = request.args.get('occasion', '').strip()
    brand = request.args.get('brand', '').strip()
    max_price = request.args.get('max_price', '')
    min_price = request.args.get('min_price', '')
    sort_by = request.args.get('sort_by', 'popular')

    sql = "SELECT * FROM perfumes WHERE 1=1"
    params = []

    if q:
        sql += " AND (name LIKE %s OR brand LIKE %s OR all_notes LIKE %s OR description LIKE %s)"
        like_q = f"%{q}%"
        params.extend([like_q, like_q, like_q, like_q])

    if family:
        sql += " AND (scent_family = %s OR secondary_family = %s)"
        params.extend([family, family])

    if gender and gender.lower() != 'all':
        sql += " AND (gender = %s OR gender = 'Unisex')"
        params.append(gender)

    if occasion:
        sql += " AND best_occasions LIKE %s"
        params.append(f"%{occasion}%")

    if brand:
        sql += " AND brand = %s"
        params.append(brand)

    if min_price:
        try:
            sql += " AND price >= %s"
            params.append(float(min_price))
        except ValueError:
            pass

    if max_price:
        try:
            sql += " AND price <= %s"
            params.append(float(max_price))
        except ValueError:
            pass

    # Execute query
    perfumes = query_db(sql, params)

    # Note filtering in python for flexible multi-tag match
    if notes:
        filtered = []
        for p in perfumes:
            p_notes = (p.get('all_notes') or '').lower()
            if any(n.lower() in p_notes for n in notes):
                filtered.append(p)
        perfumes = filtered

    # Compute match scores if user profile exists
    user_id = session.get('user_id')
    user_profile = None
    if user_id:
        user_profile = query_db("SELECT * FROM user_profiles WHERE user_id = %s", (user_id,), one=True)

    for p in perfumes:
        if user_profile:
            match_score, reasons = calculate_perfume_match(p, user_profile)
            p['match_score'] = match_score
            p['match_reasons'] = reasons
        else:
            p['match_score'] = int(round((float(p['rating_avg']) / 5.0) * 100))
            p['match_reasons'] = ["Curated Recommendation"]

    # Sorting
    if sort_by == 'match_desc':
        perfumes.sort(key=lambda x: x['match_score'], reverse=True)
    elif sort_by == 'price_asc':
        perfumes.sort(key=lambda x: float(x['price']))
    elif sort_by == 'price_desc':
        perfumes.sort(key=lambda x: float(x['price']), reverse=True)
    elif sort_by == 'rating_desc':
        perfumes.sort(key=lambda x: float(x['rating_avg']), reverse=True)
    elif sort_by == 'release_desc':
        perfumes.sort(key=lambda x: x.get('release_year', 0), reverse=True)
    else:  # popular
        perfumes.sort(key=lambda x: (float(x['rating_avg']), x['rating_count']), reverse=True)

    return jsonify({
        'status': 'success',
        'count': len(perfumes),
        'perfumes': perfumes
    })

@app.route('/perfume/<int:perfume_id>')
def perfume_detail(perfume_id):
    perfume = query_db("SELECT * FROM perfumes WHERE id = %s", (perfume_id,), one=True)
    if not perfume:
        flash("Fragrance not found.", "warning")
        return redirect(url_for('discover'))

    # Calculate match with logged-in user profile
    user_id = session.get('user_id')
    user_match_score = None
    match_reasons = []
    if user_id:
        profile = query_db("SELECT * FROM user_profiles WHERE user_id = %s", (user_id,), one=True)
        if profile:
            user_match_score, match_reasons = calculate_perfume_match(perfume, profile)

    # Fetch reviews
    reviews = query_db("""
        SELECT r.*, u.username 
        FROM reviews r 
        JOIN users u ON r.user_id = u.id 
        WHERE r.perfume_id = %s 
        ORDER BY r.created_at DESC
    """, (perfume_id,))

    # Check if current user has reviewed
    user_review = None
    if user_id:
        user_review = query_db("SELECT * FROM reviews WHERE perfume_id = %s AND user_id = %s", (perfume_id, user_id), one=True)

    # Similar perfumes (Scent Twins)
    similar_scents = get_similar_perfumes(perfume_id, limit=4)

    # Parse notes arrays for neat template rendering
    top_notes_list = [n.strip() for n in (perfume.get('top_notes') or '').split(',') if n.strip()]
    mid_notes_list = [n.strip() for n in (perfume.get('middle_notes') or '').split(',') if n.strip()]
    base_notes_list = [n.strip() for n in (perfume.get('base_notes') or '').split(',') if n.strip()]
    occasions_list = [o.strip() for o in (perfume.get('best_occasions') or '').split(',') if o.strip()]
    seasons_list = [s.strip() for s in (perfume.get('best_seasons') or '').split(',') if s.strip()]

    return render_template(
        'perfume_detail.html',
        perfume=perfume,
        top_notes=top_notes_list,
        mid_notes=mid_notes_list,
        base_notes=base_notes_list,
        occasions=occasions_list,
        seasons=seasons_list,
        reviews=reviews,
        user_review=user_review,
        similar_scents=similar_scents,
        user_match_score=user_match_score,
        match_reasons=match_reasons
    )

@app.route('/quiz')
def quiz():
    user_id = session.get('user_id')
    user_profile = None
    if user_id:
        user_profile = query_db("SELECT * FROM user_profiles WHERE user_id = %s", (user_id,), one=True)

    return render_template('quiz.html', user_profile=user_profile)

@app.route('/api/quiz-results', methods=['POST'])
def api_quiz_results():
    data = request.get_json() or {}
    families = data.get('families', [])
    notes = data.get('notes', [])
    occasions = data.get('occasions', [])
    seasons = data.get('seasons', [])
    budget_min = float(data.get('budget_min', 0) or 0)
    budget_max = float(data.get('budget_max', 350) or 350)
    longevity = data.get('longevity', 'Long Lasting')

    persona = determine_fragrance_persona(",".join(families), ",".join(notes))

    profile_dict = {
        'preferred_families': ",".join(families),
        'preferred_notes': ",".join(notes),
        'preferred_occasions': ",".join(occasions),
        'preferred_seasons': ",".join(seasons),
        'budget_min': budget_min,
        'budget_max': budget_max,
        'longevity_preference': longevity,
        'persona_title': persona['title']
    }

    # Save to user profile if user is logged in
    user_id = session.get('user_id')
    if user_id:
        execute_db("""
            INSERT INTO user_profiles 
            (user_id, preferred_families, preferred_notes, preferred_occasions, preferred_seasons, budget_min, budget_max, longevity_preference, persona_title)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
            ON DUPLICATE KEY UPDATE
            preferred_families=VALUES(preferred_families),
            preferred_notes=VALUES(preferred_notes),
            preferred_occasions=VALUES(preferred_occasions),
            preferred_seasons=VALUES(preferred_seasons),
            budget_min=VALUES(budget_min),
            budget_max=VALUES(budget_max),
            longevity_preference=VALUES(longevity_preference),
            persona_title=VALUES(persona_title)
        """, (
            user_id, profile_dict['preferred_families'], profile_dict['preferred_notes'],
            profile_dict['preferred_occasions'], profile_dict['preferred_seasons'],
            budget_min, budget_max, longevity, persona['title']
        ))

    # Calculate matches
    recommendations = get_recommendations_for_user(profile_data=profile_dict, limit=8)

    return jsonify({
        'status': 'success',
        'persona': persona,
        'matches': recommendations
    })

@app.route('/compare')
def compare():
    ids_param = request.args.get('ids', '')
    perfumes = []
    if ids_param:
        try:
            ids = [int(i.strip()) for i in ids_param.split(',') if i.strip()]
            if ids:
                # Placeholders for query
                placeholders = ', '.join(['%s'] * len(ids))
                perfumes = query_db(f"SELECT * FROM perfumes WHERE id IN ({placeholders})", ids)
                
                # Sort to preserve order of ids requested
                id_order = {val: idx for idx, val in enumerate(ids)}
                perfumes.sort(key=lambda p: id_order.get(p['id'], 0))
        except ValueError:
            pass

    # All perfumes for search dropdown
    all_perfumes = query_db("SELECT id, name, brand, scent_family, image_url, price FROM perfumes ORDER BY brand, name")

    return render_template('compare.html', perfumes=perfumes, all_perfumes=all_perfumes)

@app.route('/api/compare/details')
def api_compare_details():
    ids_param = request.args.get('ids', '')
    if not ids_param:
        return jsonify({'status': 'success', 'perfumes': []})
    try:
        ids = [int(i.strip()) for i in ids_param.split(',') if i.strip()][:4]
        if not ids:
            return jsonify({'status': 'success', 'perfumes': []})
        placeholders = ', '.join(['%s'] * len(ids))
        perfumes = query_db(f"SELECT * FROM perfumes WHERE id IN ({placeholders})", ids)
        return jsonify({'status': 'success', 'perfumes': perfumes})
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 400

@app.route('/collections')
@login_required
def collections_view():
    user_id = session['user_id']
    tab = request.args.get('tab', 'favorites')

    collections_data = {
        'favorites': query_db("""
            SELECT p.*, uc.created_at as saved_at 
            FROM user_collections uc 
            JOIN perfumes p ON uc.perfume_id = p.id 
            WHERE uc.user_id = %s AND uc.collection_type = 'favorites' 
            ORDER BY uc.created_at DESC
        """, (user_id,)),
        'wishlist': query_db("""
            SELECT p.*, uc.created_at as saved_at, uc.notes as user_notes 
            FROM user_collections uc 
            JOIN perfumes p ON uc.perfume_id = p.id 
            WHERE uc.user_id = %s AND uc.collection_type = 'wishlist' 
            ORDER BY uc.created_at DESC
        """, (user_id,)),
        'wardrobe': query_db("""
            SELECT p.*, uc.created_at as saved_at 
            FROM user_collections uc 
            JOIN perfumes p ON uc.perfume_id = p.id 
            WHERE uc.user_id = %s AND uc.collection_type = 'wardrobe' 
            ORDER BY uc.created_at DESC
        """, (user_id,))
    }

    return render_template('collections.html', collections=collections_data, active_tab=tab)

@app.route('/api/collection/toggle', methods=['POST'])
@login_required
def api_collection_toggle():
    user_id = session['user_id']
    data = request.get_json() or {}
    perfume_id = data.get('perfume_id')
    collection_type = data.get('collection_type', 'favorites')

    if not perfume_id or collection_type not in ['favorites', 'wishlist', 'wardrobe']:
        return jsonify({'status': 'error', 'message': 'Invalid parameters'}), 400

    existing = query_db(
        "SELECT id FROM user_collections WHERE user_id = %s AND perfume_id = %s AND collection_type = %s",
        (user_id, perfume_id, collection_type),
        one=True
    )

    if existing:
        execute_db(
            "DELETE FROM user_collections WHERE id = %s",
            (existing['id'],)
        )
        action = 'removed'
    else:
        execute_db(
            "INSERT INTO user_collections (user_id, perfume_id, collection_type) VALUES (%s, %s, %s)",
            (user_id, perfume_id, collection_type)
        )
        action = 'added'

    # Get updated total count for this type
    count_res = query_db(
        "SELECT COUNT(*) as cnt FROM user_collections WHERE user_id = %s AND collection_type = %s",
        (user_id, collection_type),
        one=True
    )

    return jsonify({
        'status': 'success',
        'action': action,
        'collection_type': collection_type,
        'perfume_id': perfume_id,
        'total_count': count_res['cnt'] if count_res else 0
    })

@app.route('/dashboard')
@login_required
def dashboard():
    user_id = session['user_id']
    user = query_db("SELECT * FROM users WHERE id = %s", (user_id,), one=True)
    profile = query_db("SELECT * FROM user_profiles WHERE user_id = %s", (user_id,), one=True)
    
    # Favorites
    favorites = query_db("""
        SELECT p.* FROM user_collections uc 
        JOIN perfumes p ON uc.perfume_id = p.id 
        WHERE uc.user_id = %s AND uc.collection_type = 'favorites' 
        ORDER BY uc.created_at DESC
    """, (user_id,))

    # Wishlist
    wishlist = query_db("""
        SELECT p.* FROM user_collections uc 
        JOIN perfumes p ON uc.perfume_id = p.id 
        WHERE uc.user_id = %s AND uc.collection_type = 'wishlist' 
        ORDER BY uc.created_at DESC
    """, (user_id,))

    # Wardrobe
    wardrobe = query_db("""
        SELECT p.* FROM user_collections uc 
        JOIN perfumes p ON uc.perfume_id = p.id 
        WHERE uc.user_id = %s AND uc.collection_type = 'wardrobe' 
        ORDER BY uc.created_at DESC
    """, (user_id,))

    # User reviews
    reviews = query_db("""
        SELECT r.*, p.name as perfume_name, p.brand as perfume_brand, p.image_url 
        FROM reviews r 
        JOIN perfumes p ON r.perfume_id = p.id 
        WHERE r.user_id = %s 
        ORDER BY r.created_at DESC
    """, (user_id,))

    persona = None
    if profile and profile.get('preferred_families'):
        persona = determine_fragrance_persona(
            profile['preferred_families'],
            profile.get('preferred_notes', '')
        )

    # Personalized recommendations based on their dashboard profile
    recommendations = get_recommendations_for_user(user_id=user_id, limit=4)

    return render_template(
        'dashboard.html',
        user=user,
        profile=profile,
        persona=persona,
        favorites=favorites,
        wishlist=wishlist,
        wardrobe=wardrobe,
        reviews=reviews,
        recommendations=recommendations
    )

@app.route('/profile/edit', methods=['GET', 'POST'])
@login_required
def profile_edit():
    user_id = session['user_id']
    if request.method == 'POST':
        families = request.form.getlist('families')
        notes = request.form.getlist('notes')
        occasions = request.form.getlist('occasions')
        seasons = request.form.getlist('seasons')
        budget_min = float(request.form.get('budget_min', 0) or 0)
        budget_max = float(request.form.get('budget_max', 350) or 350)
        longevity = request.form.get('longevity', 'Long Lasting')
        bio = request.form.get('bio', '')

        # Update bio in users
        execute_db("UPDATE users SET bio = %s WHERE id = %s", (bio, user_id))

        persona = determine_fragrance_persona(",".join(families), ",".join(notes))

        # Upsert profile
        execute_db("""
            INSERT INTO user_profiles 
            (user_id, preferred_families, preferred_notes, preferred_occasions, preferred_seasons, budget_min, budget_max, longevity_preference, persona_title)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
            ON DUPLICATE KEY UPDATE
            preferred_families=VALUES(preferred_families),
            preferred_notes=VALUES(preferred_notes),
            preferred_occasions=VALUES(preferred_occasions),
            preferred_seasons=VALUES(preferred_seasons),
            budget_min=VALUES(budget_min),
            budget_max=VALUES(budget_max),
            longevity_preference=VALUES(longevity_preference),
            persona_title=VALUES(persona_title)
        """, (
            user_id, ",".join(families), ",".join(notes),
            ",".join(occasions), ",".join(seasons),
            budget_min, budget_max, longevity, persona['title']
        ))

        flash("Your Fragrance Profile has been updated!", "success")
        return redirect(url_for('dashboard'))

    user = query_db("SELECT * FROM users WHERE id = %s", (user_id,), one=True)
    profile = query_db("SELECT * FROM user_profiles WHERE user_id = %s", (user_id,), one=True)
    return render_template('profile_edit.html', user=user, profile=profile)

@app.route('/api/review/add', methods=['POST'])
@login_required
def api_add_review():
    user_id = session['user_id']
    data = request.form if request.form else (request.get_json() or {})
    
    perfume_id = data.get('perfume_id')
    rating = int(data.get('rating', 5))
    longevity_rating = data.get('longevity_rating', 'Moderate')
    sillage_rating = data.get('sillage_rating', 'Moderate')
    season_vote = data.get('season_vote', 'All Season')
    title = data.get('title', '').strip()
    content = data.get('content', '').strip()

    if not perfume_id or not content:
        flash("Please provide review commentary.", "warning")
        return redirect(url_for('perfume_detail', perfume_id=perfume_id))

    # Upsert review
    execute_db("""
        INSERT INTO reviews (user_id, perfume_id, rating, longevity_rating, sillage_rating, season_vote, title, content)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
        ON DUPLICATE KEY UPDATE
        rating=VALUES(rating),
        longevity_rating=VALUES(longevity_rating),
        sillage_rating=VALUES(sillage_rating),
        season_vote=VALUES(season_vote),
        title=VALUES(title),
        content=VALUES(content)
    """, (user_id, perfume_id, rating, longevity_rating, sillage_rating, season_vote, title, content))

    # Recalculate perfume average rating
    stats = query_db("""
        SELECT COUNT(*) as count, AVG(rating) as avg_rating 
        FROM reviews WHERE perfume_id = %s
    """, (perfume_id,), one=True)

    if stats and stats['count']:
        execute_db("""
            UPDATE perfumes 
            SET rating_avg = %s, rating_count = %s 
            WHERE id = %s
        """, (round(float(stats['avg_rating']), 2), stats['count'], perfume_id))

    flash("Your fragrance review has been published!", "success")
    return redirect(url_for('perfume_detail', perfume_id=perfume_id))

# --- AUTHENTICATION ---

@app.route('/register', methods=['GET', 'POST'])
def register():
    if 'user_id' in session:
        return redirect(url_for('dashboard'))

    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        email = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')

        if not username or not email or not password:
            flash("All fields are required.", "danger")
            return render_template('register.html')

        # Check existing
        existing = query_db("SELECT id FROM users WHERE username = %s OR email = %s", (username, email), one=True)
        if existing:
            flash("Username or email already registered.", "danger")
            return render_template('register.html')

        hashed = generate_password_hash(password)
        new_id = execute_db(
            "INSERT INTO users (username, email, password_hash) VALUES (%s, %s, %s)",
            (username, email, hashed),
            return_id=True
        )

        # Initialize blank profile
        execute_db("INSERT INTO user_profiles (user_id) VALUES (%s)", (new_id,))

        session['user_id'] = new_id
        session['username'] = username
        flash(f"Welcome to ScentStory, {username}! Take the discovery quiz to find your signature match.", "success")
        return redirect(url_for('quiz'))

    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if 'user_id' in session:
        return redirect(url_for('dashboard'))

    if request.method == 'POST':
        username_or_email = request.form.get('username_or_email', '').strip()
        password = request.form.get('password', '')

        user = query_db(
            "SELECT * FROM users WHERE username = %s OR email = %s",
            (username_or_email, username_or_email),
            one=True
        )

        if user and check_password_hash(user['password_hash'], password):
            session['user_id'] = user['id']
            session['username'] = user['username']
            flash(f"Welcome back, {user['username']}!", "success")
            next_url = request.args.get('next')
            return redirect(next_url or url_for('dashboard'))
        else:
            flash("Invalid username/email or password.", "danger")

    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    flash("You have been signed out.", "info")
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
