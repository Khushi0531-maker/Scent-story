import pymysql
from werkzeug.security import generate_password_hash
from db import get_db_connection, execute_db, query_db

PERFUMES = [
    {
        "name": "Baccarat Rouge 540",
        "brand": "Maison Francis Kurkdjian",
        "concentration": "Eau de Parfum",
        "scent_family": "Sweet",
        "secondary_family": "Woody",
        "gender": "Unisex",
        "price": 325.00,
        "bottle_size_ml": 70,
        "description": "Luminous and sophisticated, Baccarat Rouge 540 lays on the skin like an amber, floral, and woody breeze. A poetic alchemy where aerial notes of jasmine and the radiance of saffron carry mineral facets of ambergris and woody tones of freshly-cut cedar.",
        "top_notes": "Bitter Almond, Saffron, Jasmine",
        "middle_notes": "Egyptian Jasmine, Cedarwood",
        "base_notes": "Ambergris, Woody Musk, Fir Resin",
        "all_notes": "Almond, Saffron, Jasmine, Cedar, Ambergris, Musk, Resin, Sweet, Warm Spicy",
        "best_occasions": "Date Night, Luxury Gala, Special Event, Evenings",
        "best_seasons": "Autumn, Winter, Spring",
        "longevity_score": 4.9,
        "sillage_score": 4.8,
        "rating_avg": 4.85,
        "rating_count": 34,
        "image_url": "https://images.unsplash.com/photo-1592945403244-b3fbafd7f539?auto=format&fit=crop&w=800&q=80",
        "release_year": 2015
    },
    {
        "name": "Sauvage Eau de Parfum",
        "brand": "Dior",
        "concentration": "Eau de Parfum",
        "scent_family": "Fresh",
        "secondary_family": "Spicy",
        "gender": "Masculine",
        "price": 145.00,
        "bottle_size_ml": 100,
        "description": "An intensely radiant trail unleashed by the juicy and spicy freshness of Reggio di Calabria Bergamot, enveloped in the smoky and sensual accents of Papua New Guinean Vanilla absolute.",
        "top_notes": "Calabrian Bergamot, Sichuan Pepper",
        "middle_notes": "Star Anise, Nutmeg, Lavender",
        "base_notes": "Papua Vanilla, Ambroxan, Cedar",
        "all_notes": "Bergamot, Sichuan Pepper, Star Anise, Nutmeg, Lavender, Vanilla, Ambroxan, Fresh, Spicy",
        "best_occasions": "Everyday, Office, Night Out, Casual",
        "best_seasons": "Spring, Summer, Autumn, Winter",
        "longevity_score": 4.6,
        "sillage_score": 4.5,
        "rating_avg": 4.65,
        "rating_count": 52,
        "image_url": "https://images.unsplash.com/photo-1523293182086-7651a899d37f?auto=format&fit=crop&w=800&q=80",
        "release_year": 2018
    },
    {
        "name": "Tobacco Vanille",
        "brand": "Tom Ford",
        "concentration": "Eau de Parfum",
        "scent_family": "Spicy",
        "secondary_family": "Sweet",
        "gender": "Unisex",
        "price": 295.00,
        "bottle_size_ml": 50,
        "description": "Opulent, warm and iconic. Tom Ford's affection for London inspired this scent, reminiscent of an English gentleman's club redolent with spice. He reinvents a classic fragrance genre by adding creamy tonka bean, vanilla, cocoa, dry fruit accords, and sweet wood sap.",
        "top_notes": "Tobacco Leaf, Spicy Notes",
        "middle_notes": "Tonka Bean, Tobacco Blossom, Vanilla, Cacao",
        "base_notes": "Dry Fruit Accord, Rich Wood Sap",
        "all_notes": "Tobacco, Vanilla, Spices, Tonka Bean, Cacao, Dried Fruits, Woody, Sweet, Warm Spicy",
        "best_occasions": "Date Night, Winter Holidays, Evening Soirée, Luxury",
        "best_seasons": "Autumn, Winter",
        "longevity_score": 4.9,
        "sillage_score": 4.7,
        "rating_avg": 4.80,
        "rating_count": 28,
        "image_url": "https://images.unsplash.com/photo-1547887537-6158d64c35b3?auto=format&fit=crop&w=800&q=80",
        "release_year": 2007
    },
    {
        "name": "Santal 33",
        "brand": "Le Labo",
        "concentration": "Eau de Parfum",
        "scent_family": "Woody",
        "secondary_family": "Fresh",
        "gender": "Unisex",
        "price": 310.00,
        "bottle_size_ml": 100,
        "description": "Imagine sitting in solitude on the rugged plains of the American West, firelight flickering on your face. Santal 33 touches the vast and wild universality of this dream with Australian sandalwood, cedarwood, cardamom, violet, and leather accords.",
        "top_notes": "Violet Accord, Cardamom, Papyrus",
        "middle_notes": "Iris, Ambrox, Cedarwood",
        "base_notes": "Australian Sandalwood, Leather Accord, Cashmeran",
        "all_notes": "Sandalwood, Cardamom, Violet, Iris, Leather, Cedar, Woody, Earthy, Powdery",
        "best_occasions": "Signature Daily, Creative Studio, Coffee Dates, Gallery Opening",
        "best_seasons": "Autumn, Spring, Winter",
        "longevity_score": 4.7,
        "sillage_score": 4.4,
        "rating_avg": 4.60,
        "rating_count": 41,
        "image_url": "https://images.unsplash.com/photo-1594035910387-fea47794261f?auto=format&fit=crop&w=800&q=80",
        "release_year": 2011
    },
    {
        "name": "Bleu de Chanel",
        "brand": "Chanel",
        "concentration": "Eau de Parfum",
        "scent_family": "Fresh",
        "secondary_family": "Woody",
        "gender": "Masculine",
        "price": 160.00,
        "bottle_size_ml": 100,
        "description": "A tribute to masculine freedom in an aromatic-woody fragrance with a captivating trail. A timeless, non-conformist scent housed in an enigmatic blue bottle, opening with vibrant citrus and settling into sophisticated cedar and amber.",
        "top_notes": "Grapefruit, Lemon, Mint, Pink Pepper",
        "middle_notes": "Ginger, Nutmeg, Jasmine, Iso E Super",
        "base_notes": "Incense, Vetiver, Cedar, Sandalwood, Patchouli",
        "all_notes": "Grapefruit, Mint, Incense, Cedar, Sandalwood, Ginger, Fresh, Woody, Citrus",
        "best_occasions": "Office, Business Meetings, Everyday, Summer Evenings",
        "best_seasons": "Spring, Summer, Autumn",
        "longevity_score": 4.5,
        "sillage_score": 4.2,
        "rating_avg": 4.75,
        "rating_count": 48,
        "image_url": "https://images.unsplash.com/photo-1588405748880-12d1d2a59f75?auto=format&fit=crop&w=800&q=80",
        "release_year": 2014
    },
    {
        "name": "Black Opium",
        "brand": "Yves Saint Laurent",
        "concentration": "Eau de Parfum",
        "scent_family": "Sweet",
        "secondary_family": "Spicy",
        "gender": "Feminine",
        "price": 155.00,
        "bottle_size_ml": 90,
        "description": "The addictive women's fragrance by Yves Saint Laurent. Captivating floral gourmand scent twisted with dark, roasted black coffee notes, energizing white flowers, and warm vanilla for a sensual adrenaline kick.",
        "top_notes": "Pear Accord, Pink Pepper, Orange Blossom",
        "middle_notes": "Black Coffee, Jasmine, Bitter Almond, Licorice",
        "base_notes": "Vanilla, Patchouli, Cedarwood, Cashmere Wood",
        "all_notes": "Coffee, Vanilla, White Flowers, Pear, Patchouli, Sweet, Warm Spicy, Gourmand",
        "best_occasions": "Clubbing, Night Out, Autumn Date Night, Concerts",
        "best_seasons": "Autumn, Winter",
        "longevity_score": 4.4,
        "sillage_score": 4.6,
        "rating_avg": 4.55,
        "rating_count": 39,
        "image_url": "https://images.unsplash.com/photo-1541643600914-78b084683601?auto=format&fit=crop&w=800&q=80",
        "release_year": 2014
    },
    {
        "name": "'REPLICA' By the Fireplace",
        "brand": "Maison Margiela",
        "concentration": "Eau de Toilette",
        "scent_family": "Woody",
        "secondary_family": "Sweet",
        "gender": "Unisex",
        "price": 165.00,
        "bottle_size_ml": 100,
        "description": "Recreating the comforting sensation of a crackling fire in Chamonix, 1971. Smoked chestnut accords and clove oil mingle with sweet vanilla and orange blossom, warming cold winter skin.",
        "top_notes": "Cloves, Pink Pepper, Orange Blossom",
        "middle_notes": "Chestnut, Guaiac Wood, Juniper",
        "base_notes": "Vanilla, Peru Balsam, Cashmeran",
        "all_notes": "Chestnut, Vanilla, Cloves, Guaiac Wood, Balsam, Woody, Sweet, Smoky, Warm",
        "best_occasions": "Winter Holidays, Cabin Getaways, Cozy Evenings, Coffee Dates",
        "best_seasons": "Autumn, Winter",
        "longevity_score": 4.5,
        "sillage_score": 4.3,
        "rating_avg": 4.68,
        "rating_count": 31,
        "image_url": "https://images.unsplash.com/photo-1595425970377-c9703cf48b6d?auto=format&fit=crop&w=800&q=80",
        "release_year": 2015
    },
    {
        "name": "Philosykos",
        "brand": "Diptyque",
        "concentration": "Eau de Parfum",
        "scent_family": "Fresh",
        "secondary_family": "Woody",
        "gender": "Unisex",
        "price": 220.00,
        "bottle_size_ml": 75,
        "description": "An ode to the whole fig tree: the green freshness of the leaves, the milky taste of the white fruit, and the dense white cedar of the bark in the warm Greek sun overlooking Mount Pelion.",
        "top_notes": "Fig Leaf, Ripe Fig",
        "middle_notes": "Coconut, Green Accords",
        "base_notes": "Cedar, Woody Notes, Fig Tree Bark",
        "all_notes": "Fig, Coconut, Cedar, Green Notes, Woody, Fresh, Creamy, Clean",
        "best_occasions": "Spring Mornings, Summer Vacations, Daily Strolls, Garden Parties",
        "best_seasons": "Spring, Summer",
        "longevity_score": 4.1,
        "sillage_score": 3.8,
        "rating_avg": 4.70,
        "rating_count": 25,
        "image_url": "https://images.unsplash.com/photo-1592945403244-b3fbafd7f539?auto=format&fit=crop&w=800&q=80",
        "release_year": 1996
    },
    {
        "name": "Aventus",
        "brand": "Creed",
        "concentration": "Eau de Parfum",
        "scent_family": "Fresh",
        "secondary_family": "Woody",
        "gender": "Masculine",
        "price": 495.00,
        "bottle_size_ml": 100,
        "description": "Sensual, audacious and contemporary, Aventus opens with mouth-watering top notes of blackcurrant and Italian bergamot, blended with Calville Blanc apples and sparkling pineapple, drying down into smoky birch and rich oakmoss.",
        "top_notes": "Pineapple, Bergamot, Blackcurrant Leaves, Apple",
        "middle_notes": "Birch, Pink Berries, Patchouli, Jasmine",
        "base_notes": "Musk, Oakmoss, Ambergris, Vanilla",
        "all_notes": "Pineapple, Birch, Bergamot, Blackcurrant, Oakmoss, Musk, Smoky, Fruity, Woody",
        "best_occasions": "Executive Meetings, Gala, Weddings, Milestone Celebrations",
        "best_seasons": "Spring, Summer, Autumn",
        "longevity_score": 4.8,
        "sillage_score": 4.7,
        "rating_avg": 4.78,
        "rating_count": 65,
        "image_url": "https://images.unsplash.com/photo-1523293182086-7651a899d37f?auto=format&fit=crop&w=800&q=80",
        "release_year": 2010
    },
    {
        "name": "Angels' Share",
        "brand": "Kilian",
        "concentration": "Eau de Parfum",
        "scent_family": "Sweet",
        "secondary_family": "Spicy",
        "gender": "Unisex",
        "price": 245.00,
        "bottle_size_ml": 50,
        "description": "Inspired by Hennessy cognac heritage, Angels' Share contains the essence of Cognac derived from the liquor to lend it a natural caramel color. Opening with cognac oil upon a blend of oak absolute, cinnamon essence, and Tonka bean absolute.",
        "top_notes": "Cognac, Hazelnut, Cinnamon",
        "middle_notes": "Cinnamon Bark, Oak Absolute, Tonka Bean",
        "base_notes": "Sandalwood, Praline, Vanilla",
        "all_notes": "Cognac, Cinnamon, Tonka, Vanilla, Praline, Oak, Sandalwood, Sweet, Warm Spicy, Boozy",
        "best_occasions": "Cocktail Parties, Intimate Dinners, Winter Nights, Luxury Lounge",
        "best_seasons": "Autumn, Winter",
        "longevity_score": 4.9,
        "sillage_score": 4.6,
        "rating_avg": 4.90,
        "rating_count": 38,
        "image_url": "https://images.unsplash.com/photo-1547887537-6158d64c35b3?auto=format&fit=crop&w=800&q=80",
        "release_year": 2020
    },
    {
        "name": "Delina",
        "brand": "Parfums de Marly",
        "concentration": "Eau de Parfum",
        "scent_family": "Floral",
        "secondary_family": "Sweet",
        "gender": "Feminine",
        "price": 375.00,
        "bottle_size_ml": 75,
        "description": "A charming and firmly modern floral bouquet. Delina is a highly nuanced fragrance which is both sweet and sensual. It overflows with Turkish rose, lily of the valley and peony accompanied by tangy notes of lychee, rhubarb and bergamot.",
        "top_notes": "Rhubarb, Lychee, Bergamot Essence, Nutmeg",
        "middle_notes": "Turkish Rose, Peony, Vanilla, Musk",
        "base_notes": "Cashmeran, Cedarwood, Incense, Vetiver",
        "all_notes": "Turkish Rose, Lychee, Peony, Rhubarb, Vanilla, Cashmeran, Floral, Sweet, Fruity",
        "best_occasions": "Daytime Luxury, Weddings, High Tea, Romantic Dates",
        "best_seasons": "Spring, Summer",
        "longevity_score": 4.8,
        "sillage_score": 4.8,
        "rating_avg": 4.82,
        "rating_count": 33,
        "image_url": "https://images.unsplash.com/photo-1594035910387-fea47794261f?auto=format&fit=crop&w=800&q=80",
        "release_year": 2017
    },
    {
        "name": "Acqua Di Giò Parfum",
        "brand": "Giorgio Armani",
        "concentration": "Parfum",
        "scent_family": "Fresh",
        "secondary_family": "Woody",
        "gender": "Masculine",
        "price": 180.00,
        "bottle_size_ml": 100,
        "description": "A powerful, charismatic fragrance featuring marine notes and incense accords. Evoking the meeting of sea and rock, with sparkling bergamot, rosemary, and heart notes of geranium over mineral patchouli.",
        "top_notes": "Marine Notes, Bergamot",
        "middle_notes": "Rosemary, Clary Sage, Geranium",
        "base_notes": "Olibanum Incense, Patchouli",
        "all_notes": "Marine, Bergamot, Rosemary, Incense, Patchouli, Fresh, Aquatic, Mineral, Clean",
        "best_occasions": "Summer Vacation, Everyday Signature, Yacht Cruise, Gym to Casual",
        "best_seasons": "Spring, Summer",
        "longevity_score": 4.5,
        "sillage_score": 4.2,
        "rating_avg": 4.65,
        "rating_count": 44,
        "image_url": "https://images.unsplash.com/photo-1588405748880-12d1d2a59f75?auto=format&fit=crop&w=800&q=80",
        "release_year": 2023
    },
    {
        "name": "Libre Eau de Parfum",
        "brand": "Yves Saint Laurent",
        "concentration": "Eau de Parfum",
        "scent_family": "Floral",
        "secondary_family": "Fresh",
        "gender": "Feminine",
        "price": 160.00,
        "bottle_size_ml": 90,
        "description": "The perfume of an unapologetic, confident woman. A floral scent uniting Moroccan orange blossom with the audacity of Diva lavender from France, enriched by sensual ambergris and Madagascar vanilla.",
        "top_notes": "Mandarin Oil, Lavender, Blackcurrant, Petitgrain",
        "middle_notes": "Jasmine, Orange Blossom, Diva Lavender",
        "base_notes": "Madagascar Vanilla, Cedar, Ambergris, Musk",
        "all_notes": "Lavender, Orange Blossom, Vanilla, Mandarin, Ambergris, Floral, Sweet, Fresh, Aromatic",
        "best_occasions": "Corporate Chic, Power Dinners, Evening Events, Daily Signature",
        "best_seasons": "Autumn, Spring, Winter",
        "longevity_score": 4.6,
        "sillage_score": 4.5,
        "rating_avg": 4.70,
        "rating_count": 47,
        "image_url": "https://images.unsplash.com/photo-1541643600914-78b084683601?auto=format&fit=crop&w=800&q=80",
        "release_year": 2019
    },
    {
        "name": "Grand Soir",
        "brand": "Maison Francis Kurkdjian",
        "concentration": "Eau de Parfum",
        "scent_family": "Sweet",
        "secondary_family": "Spicy",
        "gender": "Unisex",
        "price": 240.00,
        "bottle_size_ml": 70,
        "description": "Dress in your finest attire and polish your look. Experience the luminous energy of a grand night out in Paris. Lost in an endless night, bask in the warm, opulent radiance of benzoin, tonka bean, cistus labdanum, and amber.",
        "top_notes": "Spanish Labdanum, Warm Spices",
        "middle_notes": "Siam Benzoin, Brazilian Tonka Bean",
        "base_notes": "Amber Accord, Vanilla Absolute",
        "all_notes": "Amber, Benzoin, Tonka, Vanilla, Labdanum, Warm Spicy, Sweet, Balsamic, Opulent",
        "best_occasions": "Black Tie, Opera, Candlelit Dinner, Winter Evening",
        "best_seasons": "Autumn, Winter",
        "longevity_score": 4.9,
        "sillage_score": 4.7,
        "rating_avg": 4.88,
        "rating_count": 29,
        "image_url": "https://images.unsplash.com/photo-1595425970377-c9703cf48b6d?auto=format&fit=crop&w=800&q=80",
        "release_year": 2016
    },
    {
        "name": "Oud Wood",
        "brand": "Tom Ford",
        "concentration": "Eau de Parfum",
        "scent_family": "Woody",
        "secondary_family": "Spicy",
        "gender": "Unisex",
        "price": 295.00,
        "bottle_size_ml": 50,
        "description": "Rare, exotic, distinctive. One of the most rare, precious, and expensive ingredients in a perfumer's arsenal, oud wood is often burned in incense-filled temples. Rosewood and cardamom yield to a smoky blend of rare oud wood, sandalwood and vetiver.",
        "top_notes": "Rosewood, Cardamom, Chinese Pepper",
        "middle_notes": "Rare Oud Wood, Sandalwood, Vetiver",
        "base_notes": "Tonka Bean, Vanilla, Amber",
        "all_notes": "Oud, Sandalwood, Cardamom, Rosewood, Vanilla, Vetiver, Woody, Warm Spicy, Smoky",
        "best_occasions": "Executive Office, Formal Dinners, Evening Lounges, Autumn Strolls",
        "best_seasons": "Autumn, Winter, Spring",
        "longevity_score": 4.4,
        "sillage_score": 4.1,
        "rating_avg": 4.62,
        "rating_count": 36,
        "image_url": "https://images.unsplash.com/photo-1523293182086-7651a899d37f?auto=format&fit=crop&w=800&q=80",
        "release_year": 2007
    },
    {
        "name": "Vanilla | 28",
        "brand": "Kayali",
        "concentration": "Eau de Parfum",
        "scent_family": "Sweet",
        "secondary_family": "Floral",
        "gender": "Unisex",
        "price": 138.00,
        "bottle_size_ml": 100,
        "description": "A masterpiece of refined nuance. Rich Madagascan vanilla infused with brown sugar, jasmine petals, and Brazilian tonka bean, crowned by royal amber and patchouli. Perfect alone or layered.",
        "top_notes": "Vanilla Orchids, Creamy Jasmine",
        "middle_notes": "Madagascar Vanilla, Brazilian Tonka Bean",
        "base_notes": "Brown Sugar, Amberwoods, Patchouli, Musk",
        "all_notes": "Vanilla, Brown Sugar, Tonka Bean, Amber, Jasmine, Sweet, Gourmand, Warm",
        "best_occasions": "Cozy Weekends, Layering Base, Date Nights, Sweet Everyday",
        "best_seasons": "Autumn, Winter, Spring",
        "longevity_score": 4.5,
        "sillage_score": 4.3,
        "rating_avg": 4.72,
        "rating_count": 42,
        "image_url": "https://images.unsplash.com/photo-1547887537-6158d64c35b3?auto=format&fit=crop&w=800&q=80",
        "release_year": 2018
    },
    {
        "name": "Wood Sage & Sea Salt",
        "brand": "Jo Malone London",
        "concentration": "Cologne",
        "scent_family": "Fresh",
        "secondary_family": "Woody",
        "gender": "Unisex",
        "price": 165.00,
        "bottle_size_ml": 100,
        "description": "Escape the everyday along the windswept shore. Waves breaking white, the air fresh with sea salt and spray. Alive with the mineral scent of the rugged cliffs, mingling with the woody earthiness of sage.",
        "top_notes": "Ambrette Seeds, Grapefruit",
        "middle_notes": "Sea Salt Accord, Mineral Drift",
        "base_notes": "Sage, Red Algae, Driftwood",
        "all_notes": "Sea Salt, Sage, Ambrette, Grapefruit, Driftwood, Fresh, Marine, Mineral, Clean",
        "best_occasions": "Casual Morning, Beach Walk, Brunch, Summer Picnic",
        "best_seasons": "Spring, Summer",
        "longevity_score": 3.6,
        "sillage_score": 3.4,
        "rating_avg": 4.58,
        "rating_count": 35,
        "image_url": "https://images.unsplash.com/photo-1592945403244-b3fbafd7f539?auto=format&fit=crop&w=800&q=80",
        "release_year": 2014
    },
    {
        "name": "Miss Dior Blooming Bouquet",
        "brand": "Dior",
        "concentration": "Eau de Toilette",
        "scent_family": "Floral",
        "secondary_family": "Fresh",
        "gender": "Feminine",
        "price": 140.00,
        "bottle_size_ml": 100,
        "description": "An immediate floral embrace. Designed as a tribute to Christian Dior's legendary passion for flowers, featuring a tender accord of peony and Damascus rose honed by radiant Calabrian bergamot and enveloped in white musks.",
        "top_notes": "Calabrian Bergamot, Sweet Pea",
        "middle_notes": "Damascus Rose, Peony",
        "base_notes": "White Musk, Light Patchouli",
        "all_notes": "Peony, Rose, Bergamot, White Musk, Floral, Fresh, Delicate, Romantic",
        "best_occasions": "Spring Weddings, Daytime Casual, First Dates, Garden Tea",
        "best_seasons": "Spring, Summer",
        "longevity_score": 3.9,
        "sillage_score": 3.7,
        "rating_avg": 4.62,
        "rating_count": 27,
        "image_url": "https://images.unsplash.com/photo-1594035910387-fea47794261f?auto=format&fit=crop&w=800&q=80",
        "release_year": 2014
    },
    {
        "name": "Portrait of a Lady",
        "brand": "Frederic Malle",
        "concentration": "Parfum",
        "scent_family": "Spicy",
        "secondary_family": "Floral",
        "gender": "Unisex",
        "price": 430.00,
        "bottle_size_ml": 100,
        "description": "Considered a modern baroque masterpiece. Contains an unprecedented dose of 400 Turkish roses per 100ml bottle, bound by dark patchouli, cinnamon, clove, frankincense, and blackcurrant.",
        "top_notes": "Turkish Rose, Clove, Raspberry, Blackcurrant",
        "middle_notes": "Patchouli, Sandalwood, Frankincense",
        "base_notes": "Amber, White Musk, Benzoin",
        "all_notes": "Turkish Rose, Patchouli, Incense, Clove, Raspberry, Amber, Spicy, Floral, Dark, Opulent",
        "best_occasions": "Gala, Red Carpet, Autumn Symphony, Midnight Encounters",
        "best_seasons": "Autumn, Winter",
        "longevity_score": 5.0,
        "sillage_score": 4.9,
        "rating_avg": 4.92,
        "rating_count": 24,
        "image_url": "https://images.unsplash.com/photo-1547887537-6158d64c35b3?auto=format&fit=crop&w=800&q=80",
        "release_year": 2010
    },
    {
        "name": "Gypsy Water",
        "brand": "Byredo",
        "concentration": "Eau de Parfum",
        "scent_family": "Woody",
        "secondary_family": "Fresh",
        "gender": "Unisex",
        "price": 290.00,
        "bottle_size_ml": 100,
        "description": "An ode to the beauty of Romany culture, its free customs and intimate belief in connection with nature. Pine needle accords and sandalwood meet amber and citrus in a dreamy, bohemian mist.",
        "top_notes": "Bergamot, Lemon, Pepper, Juniper Berries",
        "middle_notes": "Incense, Pine Needles, Orris",
        "base_notes": "Amber, Vanilla, Sandalwood",
        "all_notes": "Juniper, Pine, Lemon, Sandalwood, Vanilla, Incense, Woody, Fresh, Aromatic, Dreamy",
        "best_occasions": "Weekend Getaways, Creative Writing, Morning Meditation, Casual Chic",
        "best_seasons": "Spring, Autumn, Summer",
        "longevity_score": 3.8,
        "sillage_score": 3.5,
        "rating_avg": 4.54,
        "rating_count": 30,
        "image_url": "https://images.unsplash.com/photo-1592945403244-b3fbafd7f539?auto=format&fit=crop&w=800&q=80",
        "release_year": 2008
    },
    {
        "name": "Lost Cherry",
        "brand": "Tom Ford",
        "concentration": "Eau de Parfum",
        "scent_family": "Sweet",
        "secondary_family": "Spicy",
        "gender": "Unisex",
        "price": 395.00,
        "bottle_size_ml": 50,
        "description": "A full-bodied journey into the once-forbidden; a contrasting scent that reveals a tempting dichotomy of playful, candy-like gleam on the outside and luscious flesh on the inside with black cherry, bitter almond, and liqueur.",
        "top_notes": "Black Cherry, Cherry Liqueur, Bitter Almond",
        "middle_notes": "Griotte Syrup, Turkish Rose, Jasmine Sambac",
        "base_notes": "Peru Balsam, Roasted Tonka, Sandalwood, Vetiver, Cedar",
        "all_notes": "Black Cherry, Almond, Liqueur, Tonka, Vanilla, Balsam, Sweet, Fruity, Warm Spicy, Seductive",
        "best_occasions": "Romantic Dinner, Nightclubs, Exclusive Parties, Velvet Lounges",
        "best_seasons": "Autumn, Winter",
        "longevity_score": 4.3,
        "sillage_score": 4.4,
        "rating_avg": 4.67,
        "rating_count": 29,
        "image_url": "https://images.unsplash.com/photo-1541643600914-78b084683601?auto=format&fit=crop&w=800&q=80",
        "release_year": 2018
    },
    {
        "name": "Naxos",
        "brand": "Xerjoff",
        "concentration": "Eau de Parfum",
        "scent_family": "Spicy",
        "secondary_family": "Sweet",
        "gender": "Unisex",
        "price": 275.00,
        "bottle_size_ml": 100,
        "description": "A tribute to Sicily and Mediterranean richness. Sparkling citrus notes of bergamot and lemon blend seamlessly with sweet honey, cinnamon, lavender, and rich blonde tobacco leaves.",
        "top_notes": "Bergamot, Lemon, Lavender",
        "middle_notes": "Honey, Cinnamon, Cashmeran, Jasmine Sambac",
        "base_notes": "Tobacco Leaf, Tonka Bean, Vanilla Bean",
        "all_notes": "Honey, Tobacco, Lavender, Cinnamon, Vanilla, Bergamot, Spicy, Sweet, Warm, Luxurious",
        "best_occasions": "Fall Evenings, Luxury Dinners, Milestone Celebrations, Club Lounge",
        "best_seasons": "Autumn, Winter, Spring",
        "longevity_score": 4.9,
        "sillage_score": 4.8,
        "rating_avg": 4.91,
        "rating_count": 37,
        "image_url": "https://images.unsplash.com/photo-1547887537-6158d64c35b3?auto=format&fit=crop&w=800&q=80",
        "release_year": 2015
    },
    {
        "name": "Paradoxe",
        "brand": "Prada",
        "concentration": "Eau de Parfum",
        "scent_family": "Floral",
        "secondary_family": "Sweet",
        "gender": "Feminine",
        "price": 155.00,
        "bottle_size_ml": 90,
        "description": "Captures the essence of the undefinable and ever-evolving Prada woman. Neroli bud extraction captures the flower's fresh crispness, merged with bio-converted amber and a revolutionary musk molecule.",
        "top_notes": "Pear, Tangerine, Calabrian Bergamot",
        "middle_notes": "Neroli, Orange Blossom, Jasmine Sambac",
        "base_notes": "Bourbon Vanilla, Amber, White Musk, Benzoin",
        "all_notes": "Neroli, Orange Blossom, Pear, Vanilla, Amber, White Musk, Floral, Sweet, Fresh",
        "best_occasions": "Everyday Elegance, Brunch, Date Night, Shopping Days",
        "best_seasons": "Spring, Summer, Autumn",
        "longevity_score": 4.6,
        "sillage_score": 4.4,
        "rating_avg": 4.68,
        "rating_count": 34,
        "image_url": "https://images.unsplash.com/photo-1588405748880-12d1d2a59f75?auto=format&fit=crop&w=800&q=80",
        "release_year": 2022
    },
    {
        "name": "Jazz Club",
        "brand": "Maison Margiela",
        "concentration": "Eau de Toilette",
        "scent_family": "Spicy",
        "secondary_family": "Sweet",
        "gender": "Masculine",
        "price": 165.00,
        "bottle_size_ml": 100,
        "description": "Brooklyn, 2013. The scent of cocktails spilling over leather armchairs, saxophones humming under dim lights, and sweet tobacco smoke rising through speakeasy beams.",
        "top_notes": "Pink Pepper, Primofiore Lemon, Neroli Oil",
        "middle_notes": "Rum Absolute, Clary Sage, Java Vetiver",
        "base_notes": "Tobacco Leaf, Vanilla Bean, Styrax Resin",
        "all_notes": "Rum, Tobacco, Vanilla, Pink Pepper, Vetiver, Spicy, Sweet, Boozy, Warm",
        "best_occasions": "Bar Lounges, Autumn Nights, Concerts, Cozy Dates",
        "best_seasons": "Autumn, Winter",
        "longevity_score": 4.4,
        "sillage_score": 4.2,
        "rating_avg": 4.74,
        "rating_count": 40,
        "image_url": "https://images.unsplash.com/photo-1523293182086-7651a899d37f?auto=format&fit=crop&w=800&q=80",
        "release_year": 2013
    }
]

USERS = [
    {
        "username": "scent_curator",
        "email": "curator@scentstory.com",
        "password": "password123",
        "bio": "Certified Sommelier of Scent. Passionate about niche perfumes, amber accords, and complex drydowns.",
        "profile": {
            "preferred_families": "Woody,Spicy,Sweet",
            "preferred_notes": "Sandalwood,Vanilla,Amber,Tobacco,Cardamom",
            "disliked_notes": "Aquatic",
            "preferred_occasions": "Date Night,Luxury Gala,Evenings",
            "preferred_seasons": "Autumn,Winter",
            "budget_min": 100,
            "budget_max": 400,
            "longevity_preference": "Beast Mode",
            "persona_title": "The Nocturnal Connoisseur"
        }
    },
    {
        "username": "aria_bloom",
        "email": "aria@scentstory.com",
        "password": "password123",
        "bio": "Searching for fresh, uplifting floral trails that brighten any room effortlessly.",
        "profile": {
            "preferred_families": "Floral,Fresh",
            "preferred_notes": "Rose,Bergamot,Peony,Jasmine,White Musk",
            "disliked_notes": "Oud,Leather",
            "preferred_occasions": "Everyday,Spring Mornings,Brunch",
            "preferred_seasons": "Spring,Summer",
            "budget_min": 50,
            "budget_max": 250,
            "longevity_preference": "Moderate",
            "persona_title": "The Sun-Drenched Minimalist"
        }
    }
]

SAMPLE_REVIEWS = [
    {
        "perfume_name": "Baccarat Rouge 540",
        "username": "scent_curator",
        "rating": 5,
        "longevity_rating": "Eternal",
        "sillage_rating": "Enormous",
        "season_vote": "Fall",
        "title": "A transcendent signature scent that commands the room",
        "content": "The burnt-sugar ambergris warmth combined with ethereal saffron is unmistakable. Two sprays on skin last easily 14+ hours. People stop me in hallways asking what I am wearing. Worth every penny."
    },
    {
        "perfume_name": "Tobacco Vanille",
        "username": "scent_curator",
        "rating": 5,
        "longevity_rating": "Eternal",
        "sillage_rating": "Strong",
        "season_vote": "Winter",
        "title": "Pure comfort in a luxury flacon",
        "content": "Smells like entering a private Mayfair library beside a hearth. Dried fruits, spices, and velvety bourbon vanilla round off the dried tobacco leaves seamlessly."
    },
    {
        "perfume_name": "Delina",
        "username": "aria_bloom",
        "rating": 5,
        "longevity_rating": "Long Lasting",
        "sillage_rating": "Strong",
        "season_vote": "Spring",
        "title": "The queen of contemporary rose fragrances",
        "content": "The tart rhubarb and juicy lychee prevent the Turkish rose from ever smelling dated or powdery. It's vibrant, youthful, yet deeply elegant. Always gets compliments."
    },
    {
        "perfume_name": "Santal 33",
        "username": "aria_bloom",
        "rating": 4,
        "longevity_rating": "Long Lasting",
        "sillage_rating": "Moderate",
        "season_vote": "All Season",
        "title": "Unique, artistic leather and cardamom-kissed sandalwood",
        "content": "Very distinct Australian sandalwood that dries down into a smooth, powdery papyrus accord. Modern, unisex, and instantly recognizable."
    }
]

def seed():
    conn, is_sqlite = get_db_connection()
    try:
        # Check if perfumes table already populated
        existing = query_db("SELECT COUNT(*) as cnt FROM perfumes", one=True)
        if existing and existing['cnt'] > 0:
            print(f"[Seed] Database already has {existing['cnt']} perfumes. Skipping seed or verifying users.")
        else:
            print("[Seed] Seeding perfume catalog...")
            for p in PERFUMES:
                sql = """
                    INSERT INTO perfumes 
                    (name, brand, concentration, scent_family, secondary_family, gender, price, bottle_size_ml, 
                     description, top_notes, middle_notes, base_notes, all_notes, best_occasions, best_seasons, 
                     longevity_score, sillage_score, rating_avg, rating_count, image_url, release_year)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                """
                execute_db(sql, (
                    p['name'], p['brand'], p['concentration'], p['scent_family'], p['secondary_family'],
                    p['gender'], p['price'], p['bottle_size_ml'], p['description'], p['top_notes'],
                    p['middle_notes'], p['base_notes'], p['all_notes'], p['best_occasions'], p['best_seasons'],
                    p['longevity_score'], p['sillage_score'], p['rating_avg'], p['rating_count'],
                    p['image_url'], p['release_year']
                ))
            print(f"[Seed] Successfully inserted {len(PERFUMES)} perfumes.")

        # Seed Users & Profiles
        for u in USERS:
            existing_user = query_db("SELECT id FROM users WHERE username = %s", (u['username'],), one=True)
            if not existing_user:
                hashed = generate_password_hash(u['password'])
                user_id = execute_db(
                    "INSERT INTO users (username, email, password_hash, bio) VALUES (%s, %s, %s, %s)",
                    (u['username'], u['email'], hashed, u['bio']),
                    return_id=True
                )
                prof = u['profile']
                execute_db("""
                    INSERT INTO user_profiles 
                    (user_id, preferred_families, preferred_notes, disliked_notes, preferred_occasions, preferred_seasons, budget_min, budget_max, longevity_preference, persona_title)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                """, (
                    user_id, prof['preferred_families'], prof['preferred_notes'], prof['disliked_notes'],
                    prof['preferred_occasions'], prof['preferred_seasons'], prof['budget_min'], prof['budget_max'],
                    prof['longevity_preference'], prof['persona_title']
                ))
                print(f"[Seed] Created demo user: {u['username']}")

        # Seed Sample Reviews & Wishlists
        for rev in SAMPLE_REVIEWS:
            user = query_db("SELECT id FROM users WHERE username = %s", (rev['username'],), one=True)
            perf = query_db("SELECT id FROM perfumes WHERE name = %s", (rev['perfume_name'],), one=True)
            if user and perf:
                exists_rev = query_db(
                    "SELECT id FROM reviews WHERE user_id = %s AND perfume_id = %s",
                    (user['id'], perf['id']), one=True
                )
                if not exists_rev:
                    execute_db("""
                        INSERT INTO reviews (user_id, perfume_id, rating, longevity_rating, sillage_rating, season_vote, title, content)
                        VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
                    """, (
                        user['id'], perf['id'], rev['rating'], rev['longevity_rating'],
                        rev['sillage_rating'], rev['season_vote'], rev['title'], rev['content']
                    ))

                # Add to favorite / wishlist collection
                execute_db("""
                    INSERT IGNORE INTO user_collections (user_id, perfume_id, collection_type)
                    VALUES (%s, %s, 'favorites')
                """, (user['id'], perf['id']))

        print("[Seed] Seeding completed successfully.")
    finally:
        conn.close()

if __name__ == '__main__':
    seed()
